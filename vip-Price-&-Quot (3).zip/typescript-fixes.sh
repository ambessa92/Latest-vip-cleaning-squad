#!/bin/bash

echo "Fixing TypeScript errors in VIP Cleaning Squad project..."

# Fix PayPal type issues in EnhancedPaymentForm.tsx
echo "Fixing PayPal types in EnhancedPaymentForm.tsx..."

# Add proper PayPal interfaces after OrderData interface
sed -i '/interface OrderData {/,/^}/a\
\
// PayPal Order Actions Interface\
interface PayPalOrderActions {\
  order: {\
    create: (orderData: PayPalOrderRequest) => Promise<string>;\
    capture: () => Promise<PayPalOrderResponse>;\
  };\
}\
\
// PayPal Order Request Interface\
interface PayPalOrderRequest {\
  purchase_units: Array<{\
    amount: {\
      value: string;\
      currency_code: string;\
      breakdown?: {\
        item_total: {\
          currency_code: string;\
          value: string;\
        };\
        tax_total?: {\
          currency_code: string;\
          value: string;\
        };\
      };\
    };\
    description?: string;\
    custom_id?: string;\
    invoice_id?: string;\
    items?: Array<{\
      name: string;\
      description: string;\
      quantity: string;\
      unit_amount: {\
        currency_code: string;\
        value: string;\
      };\
      tax?: {\
        currency_code: string;\
        value: string;\
      };\
      category: string;\
    }>;\
  }>;\
  application_context?: {\
    brand_name: string;\
    landing_page: string;\
    shipping_preference: string;\
    user_action: string;\
  };\
}\
\
// PayPal Order Response Interface\
interface PayPalOrderResponse {\
  id: string;\
  status: string;\
  purchase_units: Array<{\
    amount: {\
      value: string;\
      currency_code: string;\
    };\
  }>;\
}' hellamaid-quote-system/src/components/EnhancedPaymentForm.tsx

# Fix PayPal actions parameter types
sed -i 's/actions: Record<string, unknown>/actions: PayPalOrderActions/g' hellamaid-quote-system/src/components/EnhancedPaymentForm.tsx

# Fix subscription status inconsistencies in CustomerDashboard.tsx
echo "Fixing subscription status types in CustomerDashboard.tsx..."
sed -i "s/sub\.status === 'ACTIVE'/sub.status === 'active'/g" hellamaid-quote-system/src/components/CustomerDashboard.tsx
sed -i "s/'ACTIVE'/'active'/g" hellamaid-quote-system/src/components/CustomerDashboard.tsx
sed -i "s/'PAUSED'/'paused'/g" hellamaid-quote-system/src/components/CustomerDashboard.tsx
sed -i "s/'CANCELLED'/'cancelled'/g" hellamaid-quote-system/src/components/CustomerDashboard.tsx

# Fix pausedUntil vs pauseUntil variable naming
sed -i 's/pauseUntil:/pausedUntil:/g' hellamaid-quote-system/src/components/CustomerDashboard.tsx

echo "TypeScript fixes completed!"
echo "Running TypeScript check..."
cd hellamaid-quote-system && npm run build
