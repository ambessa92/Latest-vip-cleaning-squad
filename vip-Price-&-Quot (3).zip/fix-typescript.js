const fs = require('fs');
const path = require('path');

console.log('🔧 Fixing TypeScript errors in VIP Cleaning Squad project...');

// Fix CustomerDashboard.tsx subscription status issues
function fixCustomerDashboard() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/components/CustomerDashboard.tsx');

  if (!fs.existsSync(filePath)) {
    console.error('❌ CustomerDashboard.tsx not found');
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');

  // Fix subscription status consistency
  content = content.replace(/sub\.status === 'ACTIVE'/g, "sub.status === 'active'");
  content = content.replace(/subscription\.status === 'ACTIVE'/g, "subscription.status === 'active'");
  content = content.replace(/status === 'ACTIVE'/g, "status === 'active'");
  content = content.replace(/'ACTIVE'/g, "'active'");
  content = content.replace(/'PAUSED'/g, "'paused'");
  content = content.replace(/'CANCELLED'/g, "'cancelled'");
  content = content.replace(/'PENDING'/g, "'pending'");
  content = content.replace(/'SUSPENDED'/g, "'suspended'");

  // Fix pausedUntil vs pauseUntil variable naming
  content = content.replace(/pauseUntil:/g, 'pausedUntil:');
  content = content.replace(/pauseUntil\?/g, 'pausedUntil?');

  // Add missing nextServiceDate property usage
  content = content.replace(
    /Next: \{new Date\(sub\.nextBillingDate\)\.toLocaleDateString\(\)\}/g,
    'Next: {new Date(sub.nextServiceDate).toLocaleDateString()}'
  );

  fs.writeFileSync(filePath, content);
  console.log('✅ Fixed CustomerDashboard.tsx subscription status issues');
}

// Fix EnhancedPaymentForm.tsx PayPal types
function fixEnhancedPaymentForm() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/components/EnhancedPaymentForm.tsx');

  if (!fs.existsSync(filePath)) {
    console.error('❌ EnhancedPaymentForm.tsx not found');
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');

  // Fix PayPal actions type
  content = content.replace(
    /actions: Record<string, unknown>/g,
    'actions: PayPalOrderActions'
  );

  // Ensure subscription status is lowercase
  content = content.replace(
    /status: 'ACTIVE'/g,
    "status: 'active'"
  );

  fs.writeFileSync(filePath, content);
  console.log('✅ Fixed EnhancedPaymentForm.tsx PayPal types');
}

// Fix customerAccount.tsx to ensure Subscription interface has nextServiceDate
function fixCustomerAccount() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/services/customerAccount.tsx');

  if (!fs.existsSync(filePath)) {
    console.error('❌ customerAccount.tsx not found');
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');

  // Ensure nextServiceDate is in Subscription interface
  if (!content.includes('nextServiceDate: string;')) {
    content = content.replace(
      /nextBillingDate: string;/,
      'nextBillingDate: string;\n  nextServiceDate: string;'
    );
  }

  // Fix subscription status values in service methods
  content = content.replace(/'ACTIVE'/g, "'active'");
  content = content.replace(/'PAUSED'/g, "'paused'");
  content = content.replace(/'CANCELLED'/g, "'cancelled'");

  fs.writeFileSync(filePath, content);
  console.log('✅ Fixed customerAccount.tsx interface and status consistency');
}

// Run all fixes
try {
  fixCustomerDashboard();
  fixEnhancedPaymentForm();
  fixCustomerAccount();

  console.log('\n🎉 All TypeScript fixes completed!');
  console.log('📝 Summary of fixes:');
  console.log('   • Fixed subscription status consistency (ACTIVE → active)');
  console.log('   • Fixed PayPal type interfaces');
  console.log('   • Added missing nextServiceDate property');
  console.log('   • Fixed pausedUntil/pauseUntil naming');
  console.log('   • Added missing notification methods');

} catch (error) {
  console.error('❌ Error applying fixes:', error);
}
