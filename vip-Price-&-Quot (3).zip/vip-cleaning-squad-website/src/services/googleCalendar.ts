export interface BookingDetails {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceType: string;
  serviceDate: string;
  serviceTime: string;
  serviceAddress: string;
  serviceArea: string;
  frequency: string;
  totalAmount: number;
  cleaningType?: string;
  addOns?: string[];
}

export const createCalendarEvent = async (bookingDetails: BookingDetails): Promise<string | null> => {
  try {
    // Create booking-specific description
    const description = `
VIP Cleaning Squad Service Booking

Customer: ${bookingDetails.customerName}
Phone: ${bookingDetails.customerPhone}
Email: ${bookingDetails.customerEmail}
Service Type: ${bookingDetails.serviceType}
Cleaning Type: ${bookingDetails.cleaningType || 'Standard'}
Frequency: ${bookingDetails.frequency}
Total Amount: $${bookingDetails.totalAmount}
Service Address: ${bookingDetails.serviceAddress}
Service Area: ${bookingDetails.serviceArea}
Add-ons: ${bookingDetails.addOns?.join(', ') || 'None'}

--- VIP Cleaning Squad ---
Professional Cleaning Services
Phone: 289-697-6559
Email: info@vipcleaningsquad.ca
    `.trim();

    // Create Google Calendar URL
    const startDate = new Date(`${bookingDetails.serviceDate}T${bookingDetails.serviceTime}`);
    const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours duration

    const calendarEvent = {
      title: `VIP Cleaning Squad - ${bookingDetails.serviceType} for ${bookingDetails.customerName}`,
      startDate,
      endDate,
      description,
      location: bookingDetails.serviceAddress
    };

    console.log('📅 Calendar Event Created:', calendarEvent);

    // Return a mock event ID for now (in production, this would integrate with Google Calendar API)
    return `vip_cleaning_${Date.now()}`;
  } catch (error) {
    console.error('Calendar creation error:', error);
    return null;
  }
};

export const generateCalendarLink = (bookingDetails: BookingDetails): string => {
  const startDate = new Date(`${bookingDetails.serviceDate}T${bookingDetails.serviceTime}`);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000);

  const formatDate = (date: Date) => {
    return `${date.toISOString().replace(/[-:]/g, '').split('.')[0]}Z`;
  };

  const title = encodeURIComponent(`VIP Cleaning Squad - ${bookingDetails.serviceType}`);
  const description = encodeURIComponent(`
Customer: ${bookingDetails.customerName}
Service: ${bookingDetails.serviceType}
Amount: $${bookingDetails.totalAmount}
Address: ${bookingDetails.serviceAddress}
  `.trim());

  const location = encodeURIComponent(bookingDetails.serviceAddress);

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${formatDate(startDate)}/${formatDate(endDate)}&details=${description}&location=${location}`;
};

export const createCustomerCalendarInvite = (bookingDetails: BookingDetails) => {
  const calendarLink = generateCalendarLink(bookingDetails);

  return {
    calendarLink,
    icsData: `
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//VIP Cleaning Squad//Booking//EN
BEGIN:VEVENT
UID:${Date.now()}@vipcleaningsquad.ca
DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z
DTSTART:${new Date(`${bookingDetails.serviceDate}T${bookingDetails.serviceTime}`).toISOString().replace(/[-:]/g, '').split('.')[0]}Z
DTEND:${new Date(new Date(`${bookingDetails.serviceDate}T${bookingDetails.serviceTime}`).getTime() + 2 * 60 * 60 * 1000).toISOString().replace(/[-:]/g, '').split('.')[0]}Z
SUMMARY:VIP Cleaning Squad - ${bookingDetails.serviceType}
DESCRIPTION:Customer: ${bookingDetails.customerName}\\nService: ${bookingDetails.serviceType}\\nAmount: $${bookingDetails.totalAmount}
LOCATION:${bookingDetails.serviceAddress}
END:VEVENT
END:VCALENDAR
    `.trim()
  };
};
