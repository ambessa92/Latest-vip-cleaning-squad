// Google My Business Integration Service
export interface BusinessLocation {
  name: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  phone: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  serviceRadius: number; // in kilometers
}

export interface CustomerReview {
  id: string;
  customerName: string;
  rating: number;
  reviewText: string;
  serviceType: string;
  location: string;
  date: string;
  verified: boolean;
  response?: string;
}

export const businessLocation: BusinessLocation = {
  name: "VIP Cleaning Squad",
  address: "St. Catharines, ON",
  city: "St. Catharines",
  province: "Ontario",
  postalCode: "L2R",
  phone: "289-697-6559",
  coordinates: {
    lat: 43.1594,
    lng: -79.2469
  },
  serviceRadius: 50
};

export const serviceAreas = [
  {
    name: "St. Catharines",
    slug: "st-catharines",
    coordinates: { lat: 43.1594, lng: -79.2469 },
    population: "133,113",
    description: "Professional cleaning services in St. Catharines, Ontario's Garden City",
    keywords: ["cleaning services st catharines", "house cleaning st catharines", "maid service st catharines", "office cleaning st catharines"],
    landmarks: ["Brock University", "Port Dalhousie", "Pen Centre", "St. Catharines Museum"],
    neighborhoods: ["Downtown St. Catharines", "Port Dalhousie", "Merritton", "Grantham", "Western Hill"]
  },
  {
    name: "Niagara Falls",
    slug: "niagara-falls",
    coordinates: { lat: 43.0896, lng: -79.0849 },
    population: "88,071",
    description: "Reliable cleaning services in Niagara Falls, serving tourists and residents alike",
    keywords: ["cleaning services niagara falls", "house cleaning niagara falls", "hotel cleaning niagara falls", "commercial cleaning niagara falls"],
    landmarks: ["Niagara Falls", "Fallsview Casino", "Queen Victoria Park", "Rainbow Bridge"],
    neighborhoods: ["Tourist District", "Chippawa", "Stamford", "Falls Avenue", "University District"]
  },
  {
    name: "Niagara-on-the-Lake",
    slug: "niagara-on-the-lake",
    coordinates: { lat: 43.2557, lng: -79.0717 },
    population: "17,511",
    description: "Premium cleaning services in historic Niagara-on-the-Lake wine country",
    keywords: ["cleaning services niagara on the lake", "house cleaning notl", "winery cleaning", "heritage home cleaning"],
    landmarks: ["Shaw Festival Theatre", "Fort George", "Niagara River", "Wine Country"],
    neighborhoods: ["Old Town", "Virgil", "St. Davids", "Queenston", "Wine Route"]
  },
  {
    name: "Welland",
    slug: "welland",
    coordinates: { lat: 43.0095, lng: -79.2482 },
    population: "52,293",
    description: "Affordable cleaning services in Welland, the Rose City of Niagara",
    keywords: ["cleaning services welland", "house cleaning welland", "residential cleaning welland", "commercial cleaning welland"],
    landmarks: ["Welland Canal", "Merritt Park", "Seaway Mall", "Welland Museum"],
    neighborhoods: ["Downtown Welland", "Crown Point", "Dain City", "Cooks Mills", "Fonthill"]
  },
  {
    name: "Thorold",
    slug: "thorold",
    coordinates: { lat: 43.1226, lng: -79.1996 },
    population: "18,801",
    description: "Professional cleaning services in Thorold, preserving your historic community",
    keywords: ["cleaning services thorold", "house cleaning thorold", "residential cleaning thorold", "eco cleaning thorold"],
    landmarks: ["Welland Canal", "Short Hills Provincial Park", "Thorold Tunnel", "Battle of Beaverdams Park"],
    neighborhoods: ["Thorold South", "Allanburg", "Port Robinson", "Thorold Stone Road"]
  },
  {
    name: "Grimsby",
    slug: "grimsby",
    coordinates: { lat: 43.1926, lng: -79.5615 },
    population: "27,314",
    description: "Quality cleaning services in Grimsby, your lakeside community",
    keywords: ["cleaning services grimsby", "house cleaning grimsby", "lakefront cleaning", "residential cleaning grimsby"],
    landmarks: ["Grimsby Beach", "Forty Creek Distillery", "Grimsby Museum", "Beamer Rock"],
    neighborhoods: ["Grimsby Beach", "Nelles Corners", "Casablanca", "Forty Mile Creek"]
  },
  {
    name: "Lincoln",
    slug: "lincoln",
    coordinates: { lat: 43.1884, lng: -79.4203 },
    population: "23,787",
    description: "Trusted cleaning services in Lincoln, supporting rural and suburban homes",
    keywords: ["cleaning services lincoln ontario", "house cleaning lincoln", "rural cleaning services", "vineyard cleaning"],
    landmarks: ["Jordan Village", "Twenty Valley", "Ball's Falls", "Vineland"],
    neighborhoods: ["Beamsville", "Jordan", "Vineland", "Campden", "Twenty Mile Creek"]
  },
  {
    name: "Pelham",
    slug: "pelham",
    coordinates: { lat: 43.0354, lng: -79.3387 },
    population: "17,110",
    description: "Reliable cleaning services in Pelham, your growing community",
    keywords: ["cleaning services pelham", "house cleaning pelham", "residential cleaning pelham", "move in cleaning pelham"],
    landmarks: ["Short Hills Provincial Park", "Fonthill", "Ridgeville", "Effingham"],
    neighborhoods: ["Fonthill", "Ridgeville", "Fenwick", "North Pelham"]
  },
  {
    name: "Fort Erie",
    slug: "fort-erie",
    coordinates: { lat: 42.9059, lng: -78.9306 },
    population: "30,710",
    description: "Professional cleaning services in Fort Erie, your border community",
    keywords: ["cleaning services fort erie", "house cleaning fort erie", "cross border cleaning", "residential cleaning fort erie"],
    landmarks: ["Peace Bridge", "Fort Erie Race Track", "Crystal Beach", "Old Fort Niagara"],
    neighborhoods: ["Bridgeburg", "Crystal Beach", "Ridgeway", "Stevensville", "Point Abino"]
  },
  {
    name: "Port Colborne",
    slug: "port-colborne",
    coordinates: { lat: 42.8814, lng: -79.2508 },
    population: "18,306",
    description: "Quality cleaning services in Port Colborne, your canal city",
    keywords: ["cleaning services port colborne", "house cleaning port colborne", "canal district cleaning", "waterfront cleaning"],
    landmarks: ["Welland Canal", "Sugarloaf Marina", "H.H. Knoll Lakeview Park", "Port Colborne Historical & Marine Museum"],
    neighborhoods: ["Downtown Port Colborne", "Humberstone", "Sherkston", "Wainfleet"]
  }
];

// Google My Business API Integration
export class GoogleMyBusinessService {
  private apiKey: string;
  private placeId: string;

  constructor(apiKey: string, placeId: string) {
    this.apiKey = apiKey;
    this.placeId = placeId;
  }

  // Get business reviews from Google My Business
  async getReviews(): Promise<CustomerReview[]> {
    try {
      // In a real implementation, this would call the Google My Business API
      // For now, return mock data that matches real review structure
      return [
        {
          id: "review_001",
          customerName: "Sarah Mitchell",
          rating: 5,
          reviewText: "VIP Cleaning Squad provided excellent service! My house has never been cleaner. The team was professional, punctual, and thorough. Highly recommend!",
          serviceType: "Weekly Cleaning",
          location: "St. Catharines",
          date: "2024-01-15",
          verified: true,
          response: "Thank you Sarah! We're thrilled you're happy with our service. Your satisfaction is our priority!"
        },
        {
          id: "review_002",
          customerName: "Michael Chen",
          rating: 5,
          reviewText: "Outstanding cleaning service in Niagara Falls. They went above and beyond expectations. Very reliable and affordable pricing.",
          serviceType: "Deep Cleaning",
          location: "Niagara Falls",
          date: "2024-01-12",
          verified: true
        },
        {
          id: "review_003",
          customerName: "Jennifer Walsh",
          rating: 5,
          reviewText: "Best cleaning service in NOTL! They understand the care needed for our heritage home. Professional and trustworthy team.",
          serviceType: "Bi-weekly Cleaning",
          location: "Niagara-on-the-Lake",
          date: "2024-01-10",
          verified: true,
          response: "Thank you Jennifer! We take special pride in caring for Niagara's beautiful heritage homes."
        }
      ];
    } catch (error) {
      console.error('Error fetching Google reviews:', error);
      return [];
    }
  }

  // Post response to Google review
  async respondToReview(reviewId: string, response: string): Promise<boolean> {
    try {
      // In real implementation, this would use GMB API to post responses
      console.log(`Responding to review ${reviewId}: ${response}`);
      return true;
    } catch (error) {
      console.error('Error responding to review:', error);
      return false;
    }
  }

  // Generate Google My Business posting content
  generateGMBPost(serviceArea: string, serviceType: string): string {
    const posts = [
      `🏠 Professional ${serviceType} now available in ${serviceArea}! Get your instant quote today and experience the VIP difference. ⭐⭐⭐⭐⭐`,
      `✨ Spring cleaning season in ${serviceArea}! Book your ${serviceType} service and enjoy a spotless home. Call (289) 697-6559 for same-day service!`,
      `🧽 Trusted by hundreds of ${serviceArea} residents! Our ${serviceType} service includes satisfaction guarantee. Book online at vipcleaningsquad.ca`,
      `💎 VIP treatment for your ${serviceArea} home! Professional ${serviceType} with eco-friendly products. Fully insured & bonded.`
    ];

    return posts[Math.floor(Math.random() * posts.length)];
  }
}

// Review collection and management
export const collectCustomerReview = async (bookingData: {
  customerName: string;
  email: string;
  serviceType: string;
  location: string;
  bookingId: string;
}): Promise<void> => {
  try {
    // Send follow-up email 24 hours after service for review collection
    const reviewRequest = {
      customerName: bookingData.customerName,
      serviceType: bookingData.serviceType,
      location: bookingData.location,
      googleReviewLink: `https://g.page/vip-cleaning-squad/review`,
      incentive: "10% off your next cleaning service"
    };

    console.log('Review collection initiated:', reviewRequest);

    // In real implementation, this would:
    // 1. Schedule automated email 24 hours post-service
    // 2. Include direct Google review link
    // 3. Offer incentive for honest reviews
    // 4. Track review completion rates

  } catch (error) {
    console.error('Error initiating review collection:', error);
  }
};

// Generate local business schema for each service area
export const generateLocalBusinessSchema = (serviceArea: typeof serviceAreas[0]) => {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": `https://www.vipcleaningsquad.ca/${serviceArea.slug}`,
    "name": `VIP Cleaning Squad - ${serviceArea.name}`,
    "image": "https://www.vipcleaningsquad.ca/logo.png",
    "url": `https://www.vipcleaningsquad.ca/${serviceArea.slug}`,
    "telephone": "289-697-6559",
    "email": "info@vipcleaningsquad.ca",
    "priceRange": "$89-$500",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": serviceArea.name,
      "addressRegion": "ON",
      "addressCountry": "CA"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": serviceArea.coordinates.lat,
      "longitude": serviceArea.coordinates.lng
    },
    "areaServed": {
      "@type": "City",
      "name": serviceArea.name,
      "containedInPlace": {
        "@type": "Province",
        "name": "Ontario"
      }
    },
    "serviceType": [
      "Residential Cleaning",
      "Commercial Cleaning",
      "Deep Cleaning",
      "Move-in/Move-out Cleaning",
      "Office Cleaning"
    ],
    "description": serviceArea.description,
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "127",
      "bestRating": "5"
    },
    "openingHours": [
      "Mo-Fr 08:00-22:00",
      "Sa 09:00-19:00"
    ],
    "paymentAccepted": "Cash, Credit Card, PayPal",
    "currenciesAccepted": "CAD"
  };
};
