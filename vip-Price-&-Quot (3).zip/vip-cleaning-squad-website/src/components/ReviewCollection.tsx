"use client";

import { useState, useEffect } from 'react';
import { GoogleMyBusinessService, type CustomerReview, collectCustomerReview } from '../services/googleMyBusiness';

interface ReviewCollectionProps {
  serviceArea: string;
  onReviewSubmitted?: () => void;
}

export default function ReviewCollection({ serviceArea, onReviewSubmitted }: ReviewCollectionProps) {
  const [reviews, setReviews] = useState<CustomerReview[]>([]);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mock GMB service - in production, you'd use real API keys
  const gmbService = new GoogleMyBusinessService('mock-api-key', 'mock-place-id');

  useEffect(() => {
    loadReviews();
  }, []);

  const loadReviews = async () => {
    try {
      const fetchedReviews = await gmbService.getReviews();
      // Filter reviews for current service area
      const localReviews = fetchedReviews.filter(review =>
        review.location.toLowerCase().includes(serviceArea.toLowerCase())
      );
      setReviews(localReviews);
    } catch (error) {
      console.error('Error loading reviews:', error);
    }
  };

  const ReviewCard = ({ review }: { review: CustomerReview }) => (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
      <div className="flex items-center mb-4">
        <div className="flex text-yellow-400 text-lg">
          {[...Array(review.rating)].map((_, i) => (
            <span key={`star-${review.id}-${i}`}>⭐</span>
          ))}
        </div>
        {review.verified && (
          <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full font-medium">
            ✓ Google Verified
          </span>
        )}
        <span className="ml-auto text-xs text-gray-500">
          {new Date(review.date).toLocaleDateString()}
        </span>
      </div>

      <blockquote className="text-gray-700 mb-4 italic">
        "{review.reviewText}"
      </blockquote>

      <div className="border-t border-gray-100 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
              {review.customerName.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="ml-3">
              <p className="font-semibold text-gray-900">{review.customerName}</p>
              <p className="text-gray-500 text-sm">{review.location} • {review.serviceType}</p>
            </div>
          </div>

          {!review.response && (
            <button
              onClick={() => handleReviewResponse(review.id)}
              className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            >
              Respond
            </button>
          )}
        </div>

        {review.response && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-900 font-medium mb-1">Response from VIP Cleaning Squad:</p>
            <p className="text-sm text-blue-800">{review.response}</p>
          </div>
        )}
      </div>
    </div>
  );

  const handleReviewResponse = async (reviewId: string) => {
    const response = prompt('Enter your response to this review:');
    if (response) {
      const success = await gmbService.respondToReview(reviewId, response);
      if (success) {
        await loadReviews(); // Reload reviews to show response
        alert('Response posted successfully!');
      }
    }
  };

  const GoogleReviewButton = () => (
    <div className="bg-gradient-to-r from-blue-600 to-green-600 p-8 rounded-xl text-white text-center">
      <h3 className="text-2xl font-bold mb-4">Love Our Service?</h3>
      <p className="mb-6">Help other {serviceArea} residents discover VIP Cleaning Squad by leaving us a Google review!</p>

      <div className="space-y-4">
        <a
          href="https://g.page/vip-cleaning-squad/review"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
        >
          📝 Write a Google Review
        </a>

        <div className="text-sm opacity-90">
          <p>⭐ Takes less than 2 minutes</p>
          <p>🎁 Get 10% off your next cleaning service!</p>
        </div>
      </div>
    </div>
  );

  const ReviewStats = () => {
    const totalReviews = reviews.length;
    const averageRating = totalReviews > 0
      ? (reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews).toFixed(1)
      : '5.0';

    return (
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
        <div className="text-center">
          <div className="text-4xl font-bold text-green-600 mb-2">{averageRating}</div>
          <div className="flex justify-center text-yellow-400 text-xl mb-2">
            ⭐⭐⭐⭐⭐
          </div>
          <p className="text-gray-600 text-sm">
            Based on {totalReviews}+ Google reviews from {serviceArea} customers
          </p>
          <div className="mt-4 text-xs text-gray-500">
            📍 Local {serviceArea} reviews • ✓ Verified customers only
          </div>
        </div>
      </div>
    );
  };

  const GMBPostGenerator = () => {
    const [generatedPost, setGeneratedPost] = useState('');

    const generatePost = () => {
      const post = gmbService.generateGMBPost(serviceArea, 'cleaning service');
      setGeneratedPost(post);
    };

    return (
      <div className="bg-gray-50 p-6 rounded-xl">
        <h4 className="text-lg font-semibold mb-4">📱 Google My Business Post Generator</h4>
        <button
          onClick={generatePost}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors mb-4"
        >
          Generate {serviceArea} Post
        </button>

        {generatedPost && (
          <div className="bg-white p-4 rounded-lg border">
            <p className="text-sm text-gray-700 mb-3">{generatedPost}</p>
            <div className="flex space-x-2">
              <button
                onClick={() => navigator.clipboard.writeText(generatedPost)}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                📋 Copy Text
              </button>
              <button
                onClick={generatePost}
                className="text-green-600 hover:text-green-800 text-sm font-medium"
              >
                🔄 Generate New
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Review Stats */}
      <ReviewStats />

      {/* Google Review CTA */}
      <GoogleReviewButton />

      {/* GMB Post Generator (for business management) */}
      <GMBPostGenerator />

      {/* Recent Reviews */}
      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
          Recent {serviceArea} Customer Reviews
        </h3>

        {reviews.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600">No reviews yet for {serviceArea}. Be the first to leave a review!</p>
          </div>
        )}
      </div>

      {/* Review Collection Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h4 className="text-lg font-semibold text-blue-900 mb-2">📧 Automatic Review Collection</h4>
        <p className="text-blue-800 text-sm mb-4">
          We automatically send review requests to customers 24 hours after service completion.
          This helps us maintain our high rating and gather valuable feedback.
        </p>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="bg-white p-3 rounded">
            <p className="font-medium text-gray-900">✉️ Email Follow-up</p>
            <p className="text-gray-600">Sent 24 hours post-service</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-medium text-gray-900">🎁 Review Incentive</p>
            <p className="text-gray-600">10% off next service for honest reviews</p>
          </div>
        </div>
      </div>
    </div>
  );
}
