"use client";

import React, { useEffect, useRef, useState, useCallback } from 'react';
import emailjs from '@emailjs/browser';
import { createCalendarEvent, generateCalendarLink, createCustomerCalendarInvite, type BookingDetails } from '../services/googleCalendar';
import { collectCustomerReview } from '../services/googleMyBusiness';

interface EnhancedPaymentFormProps {
  amount: number;
  customerDetails: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city?: string;
    state?: string;
    zipCode?: string;
  };
  serviceDetails: {
    serviceType: string;
    frequency: string;
    date: string;
    time: string;
    location: string;
    cleaningType?: string;
    addOns?: string[];
  };
  onPaymentSuccess: (calendarEventId?: string) => void;
  onPaymentError?: (error: string) => void;
}

// PayPal SDK types
interface PayPalOrder {
  create: (orderData: PayPalOrderData) => Promise<string>;
  capture: () => Promise<OrderData>;
}

interface PayPalActions {
  order: PayPalOrder;
}

interface PayPalOrderData {
  purchase_units: Array<{
    amount: {
      value: string;
      currency_code: string;
    };
  }>;
}

interface PayPalButtonsOptions {
  style: {
    layout: string;
    color: string;
    shape: string;
    height: number;
  };
  createOrder: (data: unknown, actions: PayPalActions) => Promise<string>;
  onApprove: (data: { orderID: string }, actions: PayPalActions) => Promise<void>;
  onError: (err: Error) => void;
  onCancel: (data: { orderID: string }) => void;
}

interface PayPalNamespace {
  Buttons: (options: PayPalButtonsOptions) => {
    render: (selector: string) => Promise<void>;
  };
}

interface OrderData {
  id?: string;
  orderID: string;
  amount?: {
    value: string;
    currency_code: string;
  };
  status?: string;
}

declare global {
  interface Window {
    paypal?: PayPalNamespace;
    ApplePaySession?: unknown;
  }
}

// Business configuration
const PAYPAL_CONFIG = {
  CLIENT_ID: "Aa8vB4DXr6emNdurQdi0fVw05XabxrMPM9aw4zHPRfXEFkhcHtFUki6rmIVarqLSH5zbAgG37O9kr2vj",
  CURRENCY: "CAD",
  INTENT: "capture"
};

const EMAILJS_CONFIG = {
  PUBLIC_KEY: "Y8wW5l5Kiho70UhwU",
  SERVICE_ID: "service_04l9qxe",
  TEMPLATE_ID: "template_azjian8"
};

export default function EnhancedPaymentForm(props: EnhancedPaymentFormProps) {
  const [isPayPalLoaded, setIsPayPalLoaded] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paypalError, setPaypalError] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<string[]>([]);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const paypalRef = useRef<HTMLDivElement>(null);

  const addDiagnostic = useCallback((message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setDiagnostics(prev => [...prev, `[${timestamp}] ${message}`]);
    console.log(`PayPal Diagnostic: ${message}`);
  }, []);

  const sendConfirmationEmail = useCallback(async (orderData: OrderData) => {
    try {
      addDiagnostic('Sending confirmation email...');

      emailjs.init(EMAILJS_CONFIG.PUBLIC_KEY);

      const emailParams = {
        customer_name: props.customerDetails.name,
        customer_email: props.customerDetails.email,
        customer_phone: props.customerDetails.phone,
        service_type: props.serviceDetails.serviceType,
        service_frequency: props.serviceDetails.frequency,
        amount: `${props.amount.toFixed(2)} CAD`,
        order_id: orderData.id || `VIP_${Date.now()}`,
        booking_date: new Date().toLocaleDateString(),
        customer_address: `${props.customerDetails.address}, ${props.customerDetails.city}, ${props.customerDetails.state} ${props.customerDetails.zipCode}`
      };

      await emailjs.send(
        EMAILJS_CONFIG.SERVICE_ID,
        EMAILJS_CONFIG.TEMPLATE_ID,
        emailParams
      );

      addDiagnostic('Confirmation email sent successfully');
    } catch (error) {
      addDiagnostic(`Email sending failed: ${error}`);
      console.error('EmailJS Error:', error);
    }
  }, [props.customerDetails, props.serviceDetails, props.amount, addDiagnostic]);

  const createCalendarEventForBooking = useCallback(async (orderData: OrderData) => {
    try {
      addDiagnostic('Creating Google Calendar event...');

      const bookingDetails: BookingDetails = {
        customerName: props.customerDetails.name,
        customerEmail: props.customerDetails.email,
        customerPhone: props.customerDetails.phone,
        serviceType: props.serviceDetails.serviceType,
        serviceDate: props.serviceDetails.date,
        serviceTime: props.serviceDetails.time,
        serviceAddress: props.customerDetails.address,
        serviceArea: props.serviceDetails.location,
        frequency: props.serviceDetails.frequency,
        totalAmount: props.amount,
        cleaningType: props.serviceDetails.cleaningType,
        addOns: props.serviceDetails.addOns || []
      };

      const eventId = await createCalendarEvent(bookingDetails);
      if (eventId) {
        addDiagnostic(`Calendar event created: ${eventId}`);

        const businessCalendarLink = generateCalendarLink(bookingDetails);
        const customerCalendarInvite = createCustomerCalendarInvite(bookingDetails);

        addDiagnostic('Calendar integration completed successfully');
        console.log('📅 Calendar Links Generated:', {
          businessCalendar: businessCalendarLink,
          customerCalendar: customerCalendarInvite.calendarLink
        });
      } else {
        addDiagnostic('Calendar event creation failed - continuing without calendar integration');
      }

    } catch (error) {
      addDiagnostic(`Calendar integration error: ${error}`);
      console.error('Google Calendar Integration Error:', error);
    }
  }, [props.customerDetails, props.serviceDetails, props.amount, addDiagnostic]);

  const loadPayPalScript = useCallback(async () => {
    try {
      addDiagnostic('Loading PayPal SDK...');

      const existingScripts = document.querySelectorAll('script[src*="paypal.com"]');
      for (const script of existingScripts) {
        script.remove();
      }

      if (window.paypal) {
        window.paypal = undefined;
      }

      const script = document.createElement('script');
      const paypalUrl = `https://www.paypal.com/sdk/js?client-id=${PAYPAL_CONFIG.CLIENT_ID}&currency=${PAYPAL_CONFIG.CURRENCY}&intent=${PAYPAL_CONFIG.INTENT}&components=buttons,funding-eligibility`;

      script.src = paypalUrl;
      script.async = true;
      script.crossOrigin = 'anonymous';

      const loadPromise = new Promise((resolve, reject) => {
        script.onload = () => {
          addDiagnostic('PayPal SDK script loaded successfully');
          setTimeout(() => {
            if (window.paypal) {
              addDiagnostic('PayPal object confirmed in window');
              resolve(true);
            } else {
              addDiagnostic('PayPal object not found after script load');
              reject(new Error('PayPal SDK loaded but window.paypal not available'));
            }
          }, 1000);
        };

        script.onerror = (error) => {
          addDiagnostic(`PayPal SDK script error: ${error}`);
          reject(new Error('Failed to load PayPal SDK'));
        };

        setTimeout(() => {
          addDiagnostic('PayPal SDK load timeout');
          reject(new Error('PayPal SDK load timeout'));
        }, 15000);
      });

      document.head.appendChild(script);
      await loadPromise;

      setIsPayPalLoaded(true);
      setPaypalError(null);
      addDiagnostic('PayPal SDK loaded successfully');

    } catch (error) {
      addDiagnostic(`PayPal SDK load failed: ${error}`);
      setPaypalError(`Failed to load PayPal: ${error}`);
    }
  }, [addDiagnostic]);

  const initializePayPalButtons = useCallback(() => {
    if (!window.paypal || !paypalRef.current) return;

    addDiagnostic('Initializing PayPal buttons...');
    paypalRef.current.innerHTML = '';

    try {
      window.paypal.Buttons({
        style: {
          layout: 'vertical',
          color: 'blue',
          shape: 'rect',
          height: 45
        },
        createOrder: (data: unknown, actions: PayPalActions) => {
          addDiagnostic(`Creating PayPal order for amount: $${props.amount}`);
          return actions.order.create({
            purchase_units: [{
              amount: {
                value: props.amount.toFixed(2),
                currency_code: 'CAD'
              }
            }]
          });
        },
        onApprove: async (data: { orderID: string }, actions: PayPalActions) => {
          addDiagnostic(`PayPal payment approved: ${data.orderID}`);
          setIsProcessing(true);

          try {
            const order = await actions.order.capture();
            addDiagnostic('Payment captured successfully');

            await sendConfirmationEmail(order);
            await createCalendarEventForBooking(order);

            // Initiate review collection process
            await collectCustomerReview({
              customerName: props.customerDetails.name,
              email: props.customerDetails.email,
              serviceType: props.serviceDetails.serviceType,
              location: props.serviceDetails.location,
              bookingId: order.id || `VIP_${Date.now()}`
            });

            props.onPaymentSuccess();
          } catch (error) {
            addDiagnostic(`Payment capture error: ${error}`);
            props.onPaymentError?.('Payment processing failed');
          } finally {
            setIsProcessing(false);
          }
        },
        onError: (err: Error) => {
          addDiagnostic(`PayPal button error: ${err.message}`);
          setPaypalError('Payment error occurred. Please try again.');
          setIsProcessing(false);
        },
        onCancel: (data: { orderID: string }) => {
          addDiagnostic('Payment cancelled by user');
          setIsProcessing(false);
        }
      }).render('.paypal-buttons-container');

      addDiagnostic('PayPal buttons rendered successfully');
    } catch (error) {
      addDiagnostic(`PayPal button initialization error: ${error}`);
      setPaypalError('Failed to initialize PayPal buttons');
    }
  }, [props.amount, props.onPaymentSuccess, props.onPaymentError, sendConfirmationEmail, addDiagnostic, createCalendarEventForBooking]);

  useEffect(() => {
    if (isPayPalLoaded && paypalRef.current) {
      initializePayPalButtons();
    }
  }, [isPayPalLoaded, initializePayPalButtons]);

  useEffect(() => {
    if (!isPayPalLoaded && !paypalError) {
      loadPayPalScript();
    }
  }, [isPayPalLoaded, paypalError, loadPayPalScript]);

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Complete Payment</h3>

      <div className="mb-6">
        <h4 className="block text-lg font-medium text-gray-900 mb-4 text-center">💳 Secure Payment with PayPal</h4>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
          <p className="text-blue-700 text-sm mb-2">
            <strong>Safe & Secure:</strong> Pay with PayPal, credit card, or debit card
          </p>
          <p className="text-blue-600 text-xs">
            Your payment information is protected by PayPal's advanced security
          </p>
        </div>
      </div>

      <div className="mb-4 space-y-2">
        <p><strong>Amount:</strong> ${props.amount.toFixed(2)}</p>
        <p><strong>Customer:</strong> {props.customerDetails.name}</p>
        <p><strong>Service:</strong> {props.serviceDetails.serviceType}</p>
        <p><strong>Frequency:</strong> {props.serviceDetails.frequency}</p>
      </div>

      <div>
        {paypalError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
            <p className="text-red-800 text-sm">
              <strong>Error:</strong> {paypalError}
            </p>
            <div className="mt-2 space-x-2">
              <button
                onClick={() => loadPayPalScript()}
                className="text-blue-600 underline text-sm hover:text-blue-800"
              >
                Try Again
              </button>
              <button
                onClick={() => setShowDiagnostics(!showDiagnostics)}
                className="text-blue-600 underline text-sm hover:text-blue-800"
              >
                {showDiagnostics ? 'Hide' : 'Show'} Details
              </button>
            </div>

            {showDiagnostics && (
              <div className="mt-3 bg-gray-100 border rounded p-2 text-xs font-mono max-h-40 overflow-y-auto">
                <p className="font-bold mb-2">Diagnostic Log:</p>
                {diagnostics.map((log, index) => (
                  <p key={`diagnostic-${index}-${log.substring(0, 20)}`} className="mb-1">{log}</p>
                ))}
              </div>
            )}
          </div>
        )}

        {!isPayPalLoaded && !paypalError && (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-3" />
            <p className="text-gray-600">Loading PayPal...</p>
          </div>
        )}

        {isPayPalLoaded && !paypalError && (
          <div>
            <div ref={paypalRef} className="paypal-buttons-container min-h-[50px]" />
            {isProcessing && (
              <div className="text-center mt-3 p-3 bg-blue-50 rounded">
                <div className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2" />
                <span className="text-sm text-blue-700">Processing your payment...</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
