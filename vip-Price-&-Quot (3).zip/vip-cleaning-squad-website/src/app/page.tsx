"use client";

import { useState } from 'react';
import Link from 'next/link';
import PriceCalculator from '../components/PriceCalculator';
import { serviceAreas } from '../services/googleMyBusiness';

const VIPCleaningSquadHomepage = () => {
  const [showCalculator, setShowCalculator] = useState(false);

  // Service areas imported from GMB service with detailed location data

  const features = [
    {
      icon: '⭐',
      title: '5-Star Rated Service',
      description: 'Consistently rated 5 stars by customers across the Niagara region'
    },
    {
      icon: '🛡️',
      title: 'Fully Insured & Bonded',
      description: 'Complete protection for your home and peace of mind'
    },
    {
      icon: '✅',
      title: 'Satisfaction Guaranteed',
      description: '100% satisfaction guaranteed or we return to make it right'
    },
    {
      icon: '🕒',
      title: 'Flexible Scheduling',
      description: 'Same-day service available, book at your convenience'
    },
    {
      icon: '🌱',
      title: 'Eco-Friendly Products',
      description: 'Safe for your family, pets, and the environment'
    },
    {
      icon: '💳',
      title: 'Secure Online Payment',
      description: 'Easy PayPal integration with instant booking confirmation'
    }
  ];

  const services = [
    {
      title: 'Residential Cleaning',
      description: 'Professional home cleaning for houses, apartments, and condos',
      features: [
        'Regular weekly, bi-weekly, or monthly cleaning',
        'One-time deep cleaning services',
        'Move-in/move-out cleaning',
        'Post-construction cleanup',
        'Kitchen and bathroom sanitization'
      ],
      startingPrice: '$89',
      popular: true
    },
    {
      title: 'Commercial Cleaning',
      description: 'Professional business cleaning for offices and commercial spaces',
      features: [
        'Daily, weekly, or monthly service schedules',
        'Office buildings and retail spaces',
        'Restaurants and medical facilities',
        'Warehouses and fitness centers',
        'Contract pricing with volume discounts'
      ],
      startingPrice: '$0.08/sq ft',
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-green-600 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative container mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            VIP Cleaning Squad
          </h1>
          <p className="text-xl md:text-2xl mb-4 max-w-3xl mx-auto">
            Professional Cleaning Services in the Niagara Region
          </p>
          <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
            Trusted by 500+ customers across St. Catharines, Niagara Falls, and surrounding areas.
            Get instant quotes, book online, and experience the VIP difference.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button
              onClick={() => setShowCalculator(true)}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
            >
              Get Instant Quote
            </button>
            <a
              href="tel:289-697-6559"
              className="bg-green-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Call (289) 697-6559
            </a>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold">500+</div>
              <div className="text-sm opacity-80">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">5⭐</div>
              <div className="text-sm opacity-80">Average Rating</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">$89</div>
              <div className="text-sm opacity-80">Starting Price</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">24hr</div>
              <div className="text-sm opacity-80">Response Time</div>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator Modal */}
      {showCalculator && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto relative">
            <button
              onClick={() => setShowCalculator(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl z-10"
            >
              ×
            </button>
            <PriceCalculator />
          </div>
        </div>
      )}

      {/* Service Areas */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Serving the Entire Niagara Region
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional cleaning services available throughout the Niagara region with same-day booking available
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {serviceAreas.map((area) => (
              <Link
                key={area.slug}
                href={`/${area.slug}`}
                className="bg-white text-blue-600 px-4 py-2 rounded-full text-sm font-medium shadow-sm border border-blue-200 hover:bg-blue-50 hover:border-blue-300 transition-all transform hover:scale-105"
              >
                📍 {area.name}
              </Link>
            ))}
          </div>

          <div className="text-center">
            <p className="text-gray-600 mb-4">Don't see your area? We're expanding! Call us to check availability.</p>
            <a
              href="tel:289-697-6559"
              className="text-blue-600 hover:text-blue-800 font-medium underline"
            >
              (289) 697-6559
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose VIP Cleaning Squad?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're not just another cleaning service. We're your trusted partners in maintaining a spotless environment.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Professional Cleaning Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From residential homes to commercial businesses, we provide comprehensive cleaning solutions tailored to your needs.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {services.map((service, index) => (
              <div
                key={index}
                className={`bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all border-2 ${
                  service.popular ? 'border-green-500 relative' : 'border-gray-100'
                }`}
              >
                {service.popular && (
                  <div className="absolute -top-3 left-6 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}

                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>

                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <span className="text-green-500 mr-2 mt-1">✓</span>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-green-600">{service.startingPrice}</span>
                    <span className="text-gray-500 ml-1">starting</span>
                  </div>
                  <button
                    onClick={() => setShowCalculator(true)}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Get Quote
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Simple 3-Step Process
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Getting professional cleaning services has never been easier
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Get Your Quote</h3>
              <p className="text-gray-600">
                Use our instant calculator to get accurate pricing based on your specific needs and preferences.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Book & Pay Securely</h3>
              <p className="text-gray-600">
                Choose your preferred date and time, then pay securely online with our PayPal integration.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-purple-600">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Enjoy Clean Spaces</h3>
              <p className="text-gray-600">
                Our professional team arrives on time with all equipment and delivers exceptional results.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => setShowCalculator(true)}
              className="bg-green-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Start Your Quote Now
            </button>
          </div>
        </div>
      </section>

      {/* Mobile Quick Access */}
      <section className="py-8 bg-blue-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-2xl font-bold mb-4">Need a Quick Quote on Mobile?</h3>
          <p className="mb-6">Access our mobile-optimized calculator for instant pricing on your phone</p>
          <a
            href="/mobile.html"
            className="bg-white text-blue-600 px-6 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all inline-block"
          >
            📱 Mobile Calculator
          </a>
        </div>
      </section>

      {/* Contact & Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">VIP Cleaning Squad</h3>
              <p className="text-gray-300 mb-4">
                Professional cleaning services across the Niagara region.
                Trusted by hundreds of satisfied customers.
              </p>
              <div className="flex space-x-4">
                <span className="text-yellow-400">⭐⭐⭐⭐⭐</span>
                <span className="text-sm text-gray-300">5.0 out of 5 stars</span>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
              <div className="space-y-3 text-gray-300">
                <div className="flex items-center">
                  <span className="mr-3">📞</span>
                  <a href="tel:289-697-6559" className="hover:text-white">(289) 697-6559</a>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">✉️</span>
                  <a href="mailto:info@vipcleaningsquad.ca" className="hover:text-white">info@vipcleaningsquad.ca</a>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">📍</span>
                  <span>Serving the Niagara Region, ON</span>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">🕒</span>
                  <span>Monday-Friday: 8AM-10PM, Saturday: 9AM-7PM</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Service Areas</h4>
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-300">
                {serviceAreas.map((area) => (
                  <Link
                    key={area.slug}
                    href={`/${area.slug}`}
                    className="hover:text-white transition-colors"
                  >
                    {area.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-300">
            <p>&copy; 2024 VIP Cleaning Squad. All rights reserved.</p>
            <p className="mt-2 text-sm">Professional cleaning services in St. Catharines, Niagara Falls, and surrounding Niagara region.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default VIPCleaningSquadHomepage;
