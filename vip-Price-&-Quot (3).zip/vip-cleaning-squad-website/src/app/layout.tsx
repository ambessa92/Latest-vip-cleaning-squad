import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VIP Cleaning Squad | Professional Cleaning Services | St. Catharines, Niagara Falls, Niagara-on-the-Lake",
  description: "Professional residential and commercial cleaning services in St. Catharines, Niagara Falls, Niagara-on-the-Lake, Welland, Thorold, Grimsby, Lincoln, Pelham, Port Colborne, and Fort Erie. Get instant quotes, book online, satisfaction guaranteed. Starting at $89.",
  keywords: [
    "cleaning services St. Catharines",
    "house cleaning Niagara Falls",
    "commercial cleaning Niagara-on-the-Lake",
    "maid service Welland",
    "office cleaning Thorold",
    "residential cleaning Grimsby",
    "deep cleaning Lincoln",
    "move out cleaning Pelham",
    "cleaning company Port Colborne",
    "janitorial services Fort Erie",
    "professional cleaners Niagara region",
    "affordable cleaning services Ontario",
    "same day cleaning service",
    "eco friendly cleaning",
    "insured cleaning company",
    "satisfaction guaranteed cleaning"
  ].join(", "),
  authors: [{ name: "VIP Cleaning Squad" }],
  creator: "VIP Cleaning Squad",
  publisher: "VIP Cleaning Squad",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: "https://www.vipcleaningsquad.ca",
  },
  openGraph: {
    type: "website",
    locale: "en_CA",
    url: "https://www.vipcleaningsquad.ca",
    title: "VIP Cleaning Squad | Professional Cleaning Services | Niagara Region",
    description: "Professional residential and commercial cleaning services in St. Catharines, Niagara Falls, and surrounding Niagara region. Get instant quotes, book online, satisfaction guaranteed.",
    siteName: "VIP Cleaning Squad",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "VIP Cleaning Squad - Professional Cleaning Services in Niagara Region",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "VIP Cleaning Squad | Professional Cleaning Services | Niagara Region",
    description: "Professional residential and commercial cleaning services in St. Catharines, Niagara Falls, and surrounding Niagara region. Get instant quotes, book online.",
    images: ["/og-image.jpg"],
  },
  other: {
    "google-site-verification": "your-google-verification-code-here",
    "business:contact_data:street_address": "St. Catharines, ON",
    "business:contact_data:locality": "St. Catharines",
    "business:contact_data:region": "Ontario",
    "business:contact_data:postal_code": "L2R",
    "business:contact_data:country_name": "Canada",
    "business:contact_data:phone_number": "289-697-6559",
    "business:contact_data:email": "info@vipcleaningsquad.ca",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en-CA">
      <head>
        {/* Local Business Schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "@id": "https://www.vipcleaningsquad.ca",
              "name": "VIP Cleaning Squad",
              "image": "https://www.vipcleaningsquad.ca/logo.png",
              "url": "https://www.vipcleaningsquad.ca",
              "telephone": "289-697-6559",
              "email": "info@vipcleaningsquad.ca",
              "priceRange": "$89-$500",
              "address": {
                "@type": "PostalAddress",
                "addressLocality": "St. Catharines",
                "addressRegion": "ON",
                "addressCountry": "CA"
              },
              "areaServed": [
                "St. Catharines",
                "Niagara Falls",
                "Niagara-on-the-Lake",
                "Welland",
                "Thorold",
                "Grimsby",
                "Lincoln",
                "West Lincoln",
                "Pelham",
                "Port Colborne",
                "Fort Erie"
              ],
              "serviceType": ["Residential Cleaning", "Commercial Cleaning", "Deep Cleaning", "Move-in/Move-out Cleaning", "Office Cleaning"],
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Cleaning Services",
                "itemListElement": [
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Residential Cleaning",
                      "description": "Professional house cleaning services for homes and apartments"
                    },
                    "price": "89",
                    "priceCurrency": "CAD"
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Service",
                      "name": "Commercial Cleaning",
                      "description": "Professional office and commercial space cleaning"
                    },
                    "price": "0.08",
                    "priceCurrency": "CAD"
                  }
                ]
              },
              "review": {
                "@type": "Review",
                "reviewRating": {
                  "@type": "Rating",
                  "ratingValue": "5",
                  "bestRating": "5"
                },
                "author": {
                  "@type": "Person",
                  "name": "Sarah Mitchell"
                },
                "reviewBody": "VIP Cleaning Squad has been amazing! My house has never been cleaner and the team is so professional."
              },
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "reviewCount": "127",
                "bestRating": "5"
              },
              "openingHours": [
                "Mo-Fr 08:00-22:00",
                "Sa 09:00-19:00"
              ],
              "paymentAccepted": "Cash, Credit Card, PayPal",
              "currenciesAccepted": "CAD"
            })
          }}
        />

        {/* Google Analytics */}
        <script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'GA_MEASUREMENT_ID');
            `,
          }}
        />
      </head>
      <body className="antialiased font-sans">
        {children}
      </body>
    </html>
  );
}
