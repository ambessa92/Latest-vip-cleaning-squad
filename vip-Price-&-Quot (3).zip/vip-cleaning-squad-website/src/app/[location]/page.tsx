"use client";

import { notFound } from 'next/navigation';
import { serviceAreas, generateLocalBusinessSchema } from '../../services/googleMyBusiness';
import LocationPageClient from './LocationPageClient';

interface LocationPageProps {
  params: Promise<{
    location: string;
  }>;
}

export default async function LocationPage({ params }: LocationPageProps) {
  const { location } = await params;

  // Find the service area based on the URL slug
  const serviceArea = serviceAreas.find(area => area.slug === location);

  if (!serviceArea) {
    notFound();
  }

  const localSchema = generateLocalBusinessSchema(serviceArea);

  return (
    <>
      {/* Inject local business schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(localSchema)
        }}
      />

      <LocationPageClient serviceArea={serviceArea} />
    </>
  );
}
