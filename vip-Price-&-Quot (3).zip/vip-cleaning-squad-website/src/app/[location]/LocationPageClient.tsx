"use client";

import { useState } from 'react';
import PriceCalculator from '../../components/PriceCalculator';
import ReviewCollection from '../../components/ReviewCollection';

interface ServiceArea {
  name: string;
  slug: string;
  coordinates: { lat: number; lng: number };
  population: string;
  description: string;
  keywords: string[];
  landmarks: string[];
  neighborhoods: string[];
}

interface LocationPageClientProps {
  serviceArea: ServiceArea;
}

export default function LocationPageClient({ serviceArea }: LocationPageClientProps) {
  const [showCalculator, setShowCalculator] = useState(false);

  const localServices = [
    {
      title: 'Residential Cleaning',
      description: `Professional house cleaning services for ${serviceArea.name} homes`,
      features: [
        `Trusted by ${serviceArea.name} families since 2020`,
        'Eco-friendly cleaning products safe for children and pets',
        'Flexible scheduling including weekends',
        'Satisfaction guarantee with every service',
        'Fully insured and bonded team'
      ],
      price: '$89',
      popular: true
    },
    {
      title: 'Commercial Cleaning',
      description: `Reliable business cleaning for ${serviceArea.name} offices and commercial spaces`,
      features: [
        `Serving ${serviceArea.name} businesses of all sizes`,
        'After-hours and weekend availability',
        'COVID-19 sanitization protocols',
        'Contract pricing with volume discounts',
        'Professional equipment and supplies included'
      ],
      price: '$0.08/sq ft',
      popular: false
    }
  ];

  const localTestimonials = [
    {
      name: "Sarah Mitchell",
      neighborhood: serviceArea.neighborhoods[0] || serviceArea.name,
      service: "Weekly Cleaning",
      rating: 5,
      text: `VIP Cleaning Squad has been amazing for our ${serviceArea.name} home! They're reliable, thorough, and always professional.`,
      verified: true
    },
    {
      name: "Michael Thompson",
      neighborhood: serviceArea.neighborhoods[1] || serviceArea.name,
      service: "Deep Cleaning",
      rating: 5,
      text: `Outstanding service in ${serviceArea.name}! They transformed our home and the price was very reasonable.`,
      verified: true
    },
    {
      name: "Jennifer Walsh",
      neighborhood: serviceArea.neighborhoods[2] || serviceArea.name,
      service: "Commercial Cleaning",
      rating: 5,
      text: `Professional cleaning service for our ${serviceArea.name} office. Always on time and exceeds expectations!`,
      verified: true
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-green-600 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative container mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Professional Cleaning Services in {serviceArea.name}
          </h1>
          <p className="text-xl md:text-2xl mb-4 max-w-4xl mx-auto">
            {serviceArea.description} • Population: {serviceArea.population}
          </p>
          <p className="text-lg mb-8 max-w-3xl mx-auto opacity-90">
            Trusted by hundreds of {serviceArea.name} residents and businesses.
            Get instant quotes, book online, and experience the VIP difference in your neighborhood.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button
              onClick={() => setShowCalculator(true)}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
            >
              Get {serviceArea.name} Quote
            </button>
            <a
              href="tel:289-697-6559"
              className="bg-green-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Call (289) 697-6559
            </a>
          </div>

          {/* Local Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold">50+</div>
              <div className="text-sm opacity-80">{serviceArea.name} Customers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">5⭐</div>
              <div className="text-sm opacity-80">Local Rating</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">$89</div>
              <div className="text-sm opacity-80">Starting Price</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">24hr</div>
              <div className="text-sm opacity-80">Response Time</div>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator Modal */}
      {showCalculator && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto relative">
            <button
              onClick={() => setShowCalculator(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl z-10"
            >
              ×
            </button>
            <PriceCalculator />
          </div>
        </div>
      )}

      {/* Local Landmarks & Neighborhoods */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Serving All of {serviceArea.name}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional cleaning services available throughout {serviceArea.name} with same-day booking
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Neighborhoods */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">📍 Neighborhoods We Serve</h3>
              <div className="grid grid-cols-2 gap-2">
                {serviceArea.neighborhoods.map((neighborhood) => (
                  <div key={neighborhood} className="text-gray-700 text-sm py-1">
                    • {neighborhood}
                  </div>
                ))}
              </div>
            </div>

            {/* Local Landmarks */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">🏛️ Local Landmarks</h3>
              <div className="space-y-2">
                {serviceArea.landmarks.map((landmark) => (
                  <div key={landmark} className="text-gray-700 text-sm flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-3" />
                    {landmark}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Local Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our {serviceArea.name} Cleaning Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive cleaning solutions for {serviceArea.name} homes and businesses
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {localServices.map((service) => (
              <div
                key={service.title}
                className={`bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all border-2 ${
                  service.popular ? 'border-green-500 relative' : 'border-gray-100'
                }`}
              >
                {service.popular && (
                  <div className="absolute -top-3 left-6 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Most Popular in {serviceArea.name}
                  </div>
                )}

                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>

                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <span className="text-green-500 mr-2 mt-1">✓</span>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-green-600">{service.price}</span>
                    <span className="text-gray-500 ml-1">starting</span>
                  </div>
                  <button
                    onClick={() => setShowCalculator(true)}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Get {serviceArea.name} Quote
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Google My Business Reviews Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <ReviewCollection
            serviceArea={serviceArea.name}
            onReviewSubmitted={() => {
              // Handle review submission if needed
              console.log(`Review submitted for ${serviceArea.name}`);
            }}
          />
        </div>
      </section>

      {/* Local Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What {serviceArea.name} Customers Say
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real reviews from your {serviceArea.name} neighbors
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {localTestimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 text-lg">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i}>⭐</span>
                    ))}
                  </div>
                  {testimonial.verified && (
                    <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full font-medium">
                      ✓ Verified
                    </span>
                  )}
                </div>

                <blockquote className="text-gray-700 mb-4 italic">
                  "{testimonial.text}"
                </blockquote>

                <div className="border-t border-gray-100 pt-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="ml-3">
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-gray-500 text-sm">{testimonial.neighborhood} • {testimonial.service}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Local CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready for a Cleaner {serviceArea.name} Home?
          </h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join hundreds of satisfied {serviceArea.name} customers who trust VIP Cleaning Squad
            for their home and business cleaning needs.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setShowCalculator(true)}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
            >
              Get Instant {serviceArea.name} Quote
            </button>
            <a
              href="tel:289-697-6559"
              className="bg-green-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Call (289) 697-6559 Now
            </a>
          </div>
        </div>
      </section>

      {/* Local Contact Info */}
      <section className="py-12 bg-gray-900 text-white">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">VIP Cleaning Squad - {serviceArea.name}</h3>
              <p className="text-gray-300 mb-4">
                Professional cleaning services serving {serviceArea.name} and surrounding areas.
                Your local cleaning experts since 2020.
              </p>
              <div className="flex space-x-2">
                <span className="text-yellow-400">⭐⭐⭐⭐⭐</span>
                <span className="text-sm text-gray-300">5.0 out of 5 stars in {serviceArea.name}</span>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
              <div className="space-y-3 text-gray-300">
                <div className="flex items-center">
                  <span className="mr-3">📞</span>
                  <a href="tel:289-697-6559" className="hover:text-white">(289) 697-6559</a>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">✉️</span>
                  <a href="mailto:info@vipcleaningsquad.ca" className="hover:text-white">info@vipcleaningsquad.ca</a>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">📍</span>
                  <span>Proudly serving {serviceArea.name}, ON</span>
                </div>
                <div className="flex items-center">
                  <span className="mr-3">🕒</span>
                  <span>Monday-Friday: 8AM-10PM, Saturday: 9AM-7PM</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Service Keywords</h4>
              <div className="flex flex-wrap gap-2 text-sm">
                {serviceArea.keywords.map((keyword) => (
                  <span
                    key={keyword}
                    className="bg-gray-800 text-gray-300 px-2 py-1 rounded text-xs"
                  >
                    {keyword}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-300">
            <p>&copy; 2024 VIP Cleaning Squad. All rights reserved.</p>
            <p className="mt-2 text-sm">
              Professional cleaning services in {serviceArea.name}, Ontario.
              Licensed, insured, and trusted by your community.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
