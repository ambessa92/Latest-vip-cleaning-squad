import type { Metadata } from "next";
import { serviceAreas } from '../../services/googleMyBusiness';

interface LocationLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    location: string;
  }>;
}

export async function generateMetadata({ params }: { params: Promise<{ location: string }> }): Promise<Metadata> {
  const { location } = await params;
  const serviceArea = serviceAreas.find(area => area.slug === location);

  if (!serviceArea) {
    return {
      title: "Page Not Found | VIP Cleaning Squad",
      description: "The requested page could not be found."
    };
  }

  const title = `Professional Cleaning Services in ${serviceArea.name} | VIP Cleaning Squad`;
  const description = `${serviceArea.description}. Get instant quotes for residential and commercial cleaning in ${serviceArea.name}. Trusted by locals since 2020. Call (289) 697-6559.`;

  return {
    title,
    description,
    keywords: serviceArea.keywords.join(', '),
    authors: [{ name: "VIP Cleaning Squad" }],
    creator: "VIP Cleaning Squad",
    publisher: "VIP Cleaning Squad",
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
    alternates: {
      canonical: `https://www.vipcleaningsquad.ca/${serviceArea.slug}`,
    },
    openGraph: {
      type: "website",
      locale: "en_CA",
      url: `https://www.vipcleaningsquad.ca/${serviceArea.slug}`,
      title: `VIP Cleaning Squad ${serviceArea.name} | Professional Cleaning Services`,
      description,
      siteName: "VIP Cleaning Squad",
      images: [
        {
          url: "/og-image.jpg",
          width: 1200,
          height: 630,
          alt: `VIP Cleaning Squad - Professional Cleaning Services in ${serviceArea.name}`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: `VIP Cleaning Squad ${serviceArea.name} | Professional Cleaning Services`,
      description,
      images: ["/og-image.jpg"],
    },
    other: {
      "geo.region": "CA-ON",
      "geo.placename": serviceArea.name,
      "geo.position": `${serviceArea.coordinates.lat};${serviceArea.coordinates.lng}`,
      "ICBM": `${serviceArea.coordinates.lat}, ${serviceArea.coordinates.lng}`,
      "business:contact_data:street_address": serviceArea.name,
      "business:contact_data:locality": serviceArea.name,
      "business:contact_data:region": "Ontario",
      "business:contact_data:postal_code": "L2R",
      "business:contact_data:country_name": "Canada",
      "business:contact_data:phone_number": "289-697-6559",
      "business:contact_data:email": "info@vipcleaningsquad.ca",
    },
  };
}

export async function generateStaticParams() {
  return serviceAreas.map((area) => ({
    location: area.slug,
  }));
}

export default async function LocationLayout({ children, params }: LocationLayoutProps) {
  await params; // Ensure params are resolved
  return <>{children}</>;
}
