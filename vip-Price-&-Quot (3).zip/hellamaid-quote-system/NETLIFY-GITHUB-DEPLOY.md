# 🚀 Deploy VIP Cleaning Squad via GitHub (Recommended)

## **Why GitHub Method Works Better:**
- ✅ More reliable than drag-and-drop
- ✅ Automatic deployments on updates
- ✅ Build logs and version control
- ✅ No upload size limits

## **Step-by-Step GitHub Deployment:**

### **1. Create GitHub Repository**
1. Go to https://github.com and login/signup
2. Click "New Repository" (green button)
3. Name it: `vip-cleaning-squad`
4. Make it Public
5. Click "Create repository"

### **2. Upload Your Project Files**
1. Click "uploading an existing file"
2. Drag all files from the `hellamaid-quote-system` folder:
   - `src/` folder
   - `public/` folder
   - `package.json`
   - `netlify.toml`
   - `index.html`
   - `vite.config.ts`
   - `tsconfig.json`
   - `tailwind.config.js`
   - All other files

3. Write commit message: "Initial VIP Cleaning Squad website"
4. Click "Commit changes"

### **3. Connect to Netlify**
1. Go to https://app.netlify.com
2. Click "Add new site" → "Import an existing project"
3. Choose "Deploy with GitHub"
4. Authorize GitHub connection
5. Select your `vip-cleaning-squad` repository
6. Build settings should auto-detect:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
7. Click "Deploy site"

### **4. Your Site Will Be Live!**
- Netlify will build and deploy automatically
- You'll get a random URL like `amazing-cupcake-123456.netlify.app`
- Build usually takes 2-3 minutes

### **5. Optional: Add Custom Domain**
1. Go to Site Settings → Domain Management
2. Add your custom domain
3. Update DNS settings as instructed

## **Build Configuration (Already Set):**
```toml
[build]
  command = "npm install && npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"
```

## **What You'll Get:**
✅ Professional VIP Cleaning Squad website
✅ Phone: (289) 697-6559
✅ Interactive Niagara service map
✅ Quote calculator with payment processing
✅ Mobile responsive design
✅ SEO optimized
✅ Automatic HTTPS

## **Troubleshooting:**
- If build fails: Check the build logs in Netlify
- Missing files: Make sure all project files uploaded to GitHub
- Need help: Build logs will show specific errors

This method is 100% reliable and gives you better control!
