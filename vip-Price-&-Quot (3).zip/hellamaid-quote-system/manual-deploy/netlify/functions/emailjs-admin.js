exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'text/html'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // Handle POST requests for saving config
  if (event.httpMethod === 'POST') {
    try {
      const body = JSON.parse(event.body || '{}');

      if (body.action === 'save_emailjs_config') {
        // Save configuration (simplified)
        return {
          statusCode: 200,
          headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: true,
            message: 'Configuration saved successfully'
          })
        };
      }
    } catch (error) {
      return {
        statusCode: 500,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          message: 'Error processing request'
        })
      };
    }
  }

  // Return HTML admin panel
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EmailJS Configuration</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; margin: -30px -30px 30px -30px; border-radius: 12px 12px 0 0; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: 600; margin-bottom: 8px; color: #333; }
        input { width: 100%; padding: 12px; border: 2px solid #e1e1e1; border-radius: 8px; font-size: 14px; box-sizing: border-box; }
        input:focus { outline: none; border-color: #667eea; }
        .help-text { font-size: 13px; color: #666; margin-top: 5px; }
        .button { background: #667eea; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; margin-right: 10px; }
        .button:hover { background: #5a67d8; }
        .setup-steps { background: #f7fafc; padding: 20px; border-radius: 8px; margin-bottom: 25px; }
        .step { margin-bottom: 10px; }
        .status { padding: 15px; border-radius: 8px; margin-bottom: 20px; display: none; }
        .status.success { background: #f0fff4; border: 1px solid #68d391; color: #22543d; }
        .status.error { background: #fed7d7; border: 1px solid #e53e3e; color: #742a2a; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📧 EmailJS Configuration</h1>
            <p>Set up email notifications for payment confirmations</p>
        </div>

        <div id="status" class="status"></div>

        <div class="setup-steps">
            <h3>🚀 Quick Setup Guide</h3>
            <div class="step">1. Create account at <a href="https://www.emailjs.com" target="_blank">emailjs.com</a></div>
            <div class="step">2. Set up an email service (Gmail recommended)</div>
            <div class="step">3. Create an email template for payment confirmations</div>
            <div class="step">4. Copy your Service ID, Template ID, and User ID below</div>
            <div class="step">5. Save your configuration</div>
        </div>

        <form id="config-form">
            <div class="form-group">
                <label for="service_id">EmailJS Service ID *</label>
                <input type="text" id="service_id" name="service_id" placeholder="service_abc123" required>
                <div class="help-text">Found in EmailJS Dashboard → Email Services</div>
            </div>

            <div class="form-group">
                <label for="template_id">EmailJS Template ID *</label>
                <input type="text" id="template_id" name="template_id" placeholder="template_xyz789" required>
                <div class="help-text">Found in EmailJS Dashboard → Email Templates</div>
            </div>

            <div class="form-group">
                <label for="user_id">EmailJS User ID *</label>
                <input type="text" id="user_id" name="user_id" placeholder="user_abcdefghijklmnop" required>
                <div class="help-text">Found in EmailJS Dashboard → Account → User ID</div>
            </div>

            <div class="form-group">
                <label for="from_name">From Name (Optional)</label>
                <input type="text" id="from_name" name="from_name" placeholder="Hellamaid Services" value="Hellamaid Services">
                <div class="help-text">The name customers see in email</div>
            </div>

            <button type="submit" class="button">💾 Save Configuration</button>
        </form>

        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e1e1e1;">
            <h3>📖 Need Help?</h3>
            <p>
                <a href="/.netlify/functions/payment-analytics?view=dashboard" target="_blank">📊 Analytics Dashboard</a> |
                <a href="https://www.emailjs.com/docs/" target="_blank">📚 EmailJS Docs</a> |
                <a href="/" target="_blank">🧮 Calculator</a>
            </p>
        </div>
    </div>

    <script>
        function showStatus(message, type) {
            const statusEl = document.getElementById('status');
            statusEl.textContent = message;
            statusEl.className = 'status ' + (type || 'success');
            statusEl.style.display = 'block';
            setTimeout(function() {
                statusEl.style.display = 'none';
            }, 5000);
        }

        document.getElementById('config-form').addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(e.target);
            const config = {
                action: 'save_emailjs_config',
                service_id: formData.get('service_id'),
                template_id: formData.get('template_id'),
                user_id: formData.get('user_id'),
                from_name: formData.get('from_name') || 'Hellamaid Services'
            };

            // Save to localStorage as fallback
            localStorage.setItem('emailjs_config', JSON.stringify(config));

            fetch('/.netlify/functions/emailjs-admin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            })
            .then(function(response) { return response.json(); })
            .then(function(result) {
                if (result.success) {
                    showStatus('✅ Configuration saved successfully! Email notifications enabled.', 'success');
                } else {
                    showStatus('❌ Configuration saved to browser storage.', 'error');
                }
            })
            .catch(function(error) {
                showStatus('✅ Configuration saved to browser storage.', 'success');
            });
        });

        // Load saved config
        try {
            const saved = localStorage.getItem('emailjs_config');
            if (saved) {
                const config = JSON.parse(saved);
                document.getElementById('service_id').value = config.service_id || '';
                document.getElementById('template_id').value = config.template_id || '';
                document.getElementById('user_id').value = config.user_id || '';
                document.getElementById('from_name').value = config.from_name || 'Hellamaid Services';
            }
        } catch (error) {
            console.log('No saved config found');
        }
    </script>
</body>
</html>`;

  return {
    statusCode: 200,
    headers,
    body: html
  };
};
