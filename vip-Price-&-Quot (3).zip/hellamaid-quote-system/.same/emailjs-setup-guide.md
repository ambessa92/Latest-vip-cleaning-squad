# EmailJS Configuration Guide

## 🎯 Overview
This guide will help you configure EmailJS for automatic payment confirmation emails in your PayPal payment system.

## 📧 What You'll Get
After completing this setup, customers will automatically receive professional payment confirmation emails containing:
- Payment details (amount, currency, payment ID)
- Customer information
- Service details (type, frequency, add-ons)
- Booking confirmation
- Contact information

## 🚀 Step 1: Create EmailJS Account

### 1.1 Sign Up
1. Go to [emailjs.com](https://www.emailjs.com)
2. Click "Sign Up"
3. Create your account (free tier includes 200 emails/month)

### 1.2 Verify Your Account
- Check your email and verify your account
- Log in to the EmailJS dashboard

## ⚙️ Step 2: Configure Email Service

### 2.1 Add Email Service
1. In EmailJS dashboard, click "Email Services"
2. Click "Add New Service"
3. Choose your email provider:
   - **Gmail** (recommended for most users)
   - **Outlook/Hotmail**
   - **Yahoo Mail**
   - **Custom SMTP** (for business emails)

### 2.2 Configure Gmail Service (Most Common)
1. Select "Gmail"
2. **Service ID**: Copy this value (e.g., `service_abc123`) - you'll need it later
3. Click "Connect Account"
4. Sign in to your Gmail account
5. Grant EmailJS permission to send emails
6. Test the connection

### 2.3 Alternative: Custom SMTP
If using business email:
1. Select "Custom SMTP"
2. Enter your SMTP settings:
   - **Host**: Your email server (e.g., `smtp.yourcompany.com`)
   - **Port**: Usually 587 or 465
   - **Username**: Your email address
   - **Password**: Your email password or app password
3. **Service ID**: Copy this value

## 📝 Step 3: Create Email Template

### 3.1 Create New Template
1. In EmailJS dashboard, click "Email Templates"
2. Click "Create New Template"
3. **Template ID**: Copy this value (e.g., `template_xyz789`) - you'll need it later

### 3.2 Configure Template Settings
**From Name**: `Hellamaid Services`
**From Email**: Your configured email address
**Subject**: `Payment Confirmation - Booking #{{order_id}}`
**To Email**: `{{to_email}}`

### 3.3 Email Template Content
Copy and paste this professional template:

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Confirmation</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
        .content { background: #f9f9f9; padding: 20px; }
        .payment-details { background: white; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .footer { background: #333; color: white; padding: 15px; text-align: center; font-size: 12px; }
        .amount { font-size: 24px; font-weight: bold; color: #059669; }
        .status { background: #059669; color: white; padding: 5px 10px; border-radius: 3px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧽 Hellamaid Services</h1>
            <h2>Payment Confirmation</h2>
        </div>

        <div class="content">
            <p>Dear {{customer_name}},</p>

            <p>Thank you for your payment! Your booking has been confirmed.</p>

            <div class="payment-details">
                <h3>💳 Payment Details</h3>
                <p><strong>Amount Paid:</strong> <span class="amount">{{payment_amount}}</span></p>
                <p><strong>Payment ID:</strong> {{payment_id}}</p>
                <p><strong>Order ID:</strong> {{order_id}}</p>
                <p><strong>Status:</strong> <span class="status">{{payment_status}}</span></p>
                <p><strong>Date:</strong> {{payment_date}} at {{payment_time}}</p>
            </div>

            <div class="payment-details">
                <h3>🏠 Service Details</h3>
                <p><strong>Service Type:</strong> {{service_type}}</p>
                <p><strong>Frequency:</strong> {{service_frequency}}</p>
                <p><strong>Add-ons:</strong> {{service_addons}}</p>
            </div>

            <div class="payment-details">
                <h3>📞 Contact Information</h3>
                <p><strong>Phone:</strong> {{customer_phone}}</p>
                <p><strong>Address:</strong> {{customer_address}}</p>
            </div>

            <div class="payment-details">
                <h3>📅 What's Next?</h3>
                <p>We'll contact you within 24 hours to schedule your cleaning service.</p>
                <p>If you have any questions, please contact us:</p>
                <ul>
                    <li>📧 Email: support@hellamaid.com</li>
                    <li>📞 Phone: 1-800-HELLAMAID</li>
                    <li>🌐 Website: https://hellamaid.com</li>
                </ul>
            </div>
        </div>

        <div class="footer">
            <p>© 2024 Hellamaid Services. All rights reserved.</p>
            <p>This is an automated confirmation email for your payment.</p>
        </div>
    </div>
</body>
</html>
```

### 3.4 Save Template
- Click "Save"
- Test the template by clicking "Test"

## 🔑 Step 4: Get Your User ID

### 4.1 Find User ID
1. In EmailJS dashboard, click "Account"
2. Find your "User ID" (e.g., `user_abcdefghijklmnop`)
3. Copy this value - you'll need it

## 🌐 Step 5: Configure Environment Variables

### 5.1 Add to Netlify
1. Go to your Netlify dashboard
2. Select your site: `same-ybnqabs99nd-latest`
3. Go to "Site settings" → "Environment variables"
4. Add these three variables:

| Variable Name | Value | Example |
|---------------|-------|---------|
| `VITE_EMAILJS_SERVICE_ID` | Your Service ID from Step 2 | `service_abc123` |
| `VITE_EMAILJS_TEMPLATE_ID` | Your Template ID from Step 3 | `template_xyz789` |
| `VITE_EMAILJS_USER_ID` | Your User ID from Step 4 | `user_abcdefghijklmnop` |

### 5.2 Important Notes
- ✅ Use the **exact** variable names shown above
- ✅ Values are case-sensitive
- ✅ No quotes needed in Netlify environment variables
- ✅ After adding, trigger a new deployment

## 🧪 Step 6: Test the Setup

### 6.1 Verify Configuration
1. Visit: `https://same-ybnqabs99nd-latest.netlify.app/.netlify/functions/payment-analytics?view=dashboard`
2. Check the "Email Delivery Metrics" section
3. Should show "EmailJS Status: Configured"

### 6.2 Test Payment Flow
1. Go to your live site
2. Fill out a quote form with **your real email**
3. Enter a PayPal Client ID
4. Complete a test payment
5. Check your email for the confirmation

### 6.3 Monitor Email Delivery
- Visit the analytics dashboard to monitor email delivery rates
- Check EmailJS dashboard for sent emails and quotas

## 📊 Step 7: Monitor and Optimize

### 7.1 EmailJS Dashboard Monitoring
- **Usage**: Track emails sent vs. your monthly limit
- **Logs**: View sent emails and any failures
- **Quota**: Upgrade plan if needed (more than 200 emails/month)

### 7.2 System Analytics
Access your analytics dashboard:
- **URL**: `/.netlify/functions/payment-analytics?view=dashboard`
- **Metrics**: Email delivery rate, failed emails, recent statuses
- **Alerts**: Automatic warnings if delivery rate drops

### 7.3 Best Practices
- **Test Regularly**: Send test emails to verify functionality
- **Monitor Quotas**: Check EmailJS usage monthly
- **Update Templates**: Improve email content based on feedback
- **Backup Config**: Save your EmailJS settings

## 🔧 Troubleshooting

### Common Issues

#### "EmailJS not configured" Error
**Cause**: Environment variables not set correctly
**Solution**:
1. Check variable names are exactly: `VITE_EMAILJS_SERVICE_ID`, `VITE_EMAILJS_TEMPLATE_ID`, `VITE_EMAILJS_USER_ID`
2. Redeploy after adding variables
3. Wait 5-10 minutes for deployment

#### Emails Not Sending
**Causes & Solutions**:
1. **Wrong Service ID**: Check EmailJS dashboard → Email Services
2. **Wrong Template ID**: Check EmailJS dashboard → Email Templates
3. **Wrong User ID**: Check EmailJS dashboard → Account
4. **Quota Exceeded**: Check EmailJS usage limits
5. **Invalid Email**: Verify customer email format

#### Email Goes to Spam
**Solutions**:
1. Use a professional sender email
2. Add your domain to SPF records
3. Ask customers to whitelist your email
4. Use proper email template formatting

#### Template Variables Not Working
**Common Issues**:
- Variable names must match exactly (case-sensitive)
- Use `{{variable_name}}` format
- Check template preview in EmailJS dashboard

## 📈 Upgrade Considerations

### Free Plan Limits
- **200 emails/month**
- **Basic templates**
- **Standard support**

### Paid Plans (if needed)
- **1,000+ emails/month**
- **Advanced features**
- **Priority support**
- **Custom domains**

## ✅ Configuration Checklist

- [ ] EmailJS account created and verified
- [ ] Email service connected (Gmail/SMTP)
- [ ] Email template created with payment variables
- [ ] Service ID, Template ID, and User ID obtained
- [ ] Environment variables added to Netlify
- [ ] Site redeployed after adding variables
- [ ] Test payment completed successfully
- [ ] Confirmation email received
- [ ] Analytics dashboard shows "Configured" status
- [ ] Email delivery rate monitored

## 🆘 Support

If you need help:
1. **EmailJS Support**: [EmailJS Help Center](https://www.emailjs.com/docs/)
2. **Template Issues**: Check the template variables match the code
3. **Netlify Config**: Verify environment variables in Netlify dashboard
4. **Analytics**: Use the monitoring dashboard to identify issues

Your payment system will now send professional confirmation emails automatically! 🎉
