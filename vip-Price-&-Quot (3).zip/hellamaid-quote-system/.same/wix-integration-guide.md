# Wix Integration Guide

## Quick Integration Steps

### Method 1: iframe Embed (Recommended)

1. **In Wix Editor:**
   - Add → Embed → HTML iframe
   - Paste this code:

```html
<iframe
  src="https://same-ybnqabs99nd-latest.netlify.app"
  width="100%"
  height="900px"
  frameborder="0"
  style="border: none; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
</iframe>
```

2. **Adjust Settings:**
   - Width: 100%
   - Height: 900px (or adjust as needed)
   - Responsive: Yes

### Method 2: External Link

1. **Create a button in Wix:**
   - Text: "Get Your Cleaning Quote"
   - Link: `https://same-ybnqabs99nd-latest.netlify.app`
   - Open in: New tab

### Method 3: Custom Domain (Professional)

1. **Set up subdomain:**
   - Create: `quote.yourdomain.com`
   - Point to Netlify site

2. **In Netlify:**
   - Go to Domain settings
   - Add custom domain: `quote.yourdomain.com`
   - Follow DNS setup instructions

3. **In Wix:**
   - Link to: `https://quote.yourdomain.com`

## Styling Integration

### Match Your Wix Theme
To make the calculator match your Wix site better, you can:

1. **Custom CSS (if using iframe):**
```html
<style>
  .calculator-container {
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    overflow: hidden;
  }
</style>
<iframe
  class="calculator-container"
  src="https://same-ybnqabs99nd-latest.netlify.app"
  width="100%"
  height="900px"
  frameborder="0">
</iframe>
```

2. **Hide Wix Navigation** (optional):
   - Add `?embedded=true` to URL
   - Example: `https://same-ybnqabs99nd-latest.netlify.app?embedded=true`

## Best Practices

### For Better User Experience:

1. **Page Title**: "Get Your Cleaning Quote"
2. **Description**: "Instant pricing calculator for cleaning services"
3. **Mobile Responsive**: The calculator is already mobile-friendly
4. **Loading Speed**: iframe loads instantly

### SEO Considerations:

1. **Meta Description**:
   ```
   Get instant cleaning service quotes with our advanced calculator.
   Choose your home size, services, and get accurate pricing in seconds.
   ```

2. **Page Keywords**:
   - cleaning service calculator
   - house cleaning quotes
   - cleaning price estimator
   - cleaning service pricing

## Testing Checklist

- [ ] iframe loads properly
- [ ] Calculator is fully functional
- [ ] PayPal payments work
- [ ] Mobile responsive on Wix
- [ ] Matches your site design
- [ ] Email notifications working (if configured)

## Support

If you need help with:
- **Wix Integration**: Check Wix support docs
- **Calculator Issues**: The system has built-in diagnostics
- **PayPal Setup**: Use the PayPal Client ID help feature
- **Email Setup**: Follow the EmailJS configuration guide

Your calculator is ready to integrate! 🚀
