# PayPal Payment System - Production Testing Guide

## 🎯 Overview
This guide covers end-to-end testing of the PayPal payment system including email notifications and webhook handling.

## 📋 Prerequisites

### 1. PayPal Developer Account Setup
- [ ] Create account at [developer.paypal.com](https://developer.paypal.com)
- [ ] Create a new PayPal app (Sandbox for testing, Live for production)
- [ ] Copy the Client ID from your app dashboard
- [ ] Note: Client ID format: `AeA1QIZXm8_RrG7BwkdJXYZ123456789` (30+ characters)

### 2. EmailJS Setup (Optional but Recommended)
- [ ] Create account at [emailjs.com](https://www.emailjs.com)
- [ ] Set up email service (Gmail, Outlook, etc.)
- [ ] Create email template with payment confirmation details
- [ ] Add EmailJS environment variables to Netlify:
  - `VITE_EMAILJS_SERVICE_ID`
  - `VITE_EMAILJS_TEMPLATE_ID`
  - `VITE_EMAILJS_USER_ID`

### 3. Webhook Setup (Advanced - Optional)
- [ ] Configure webhook URL in PayPal Developer Dashboard
- [ ] Webhook URL: `https://your-site.netlify.app/.netlify/functions/paypal-webhook`
- [ ] Subscribe to events: `PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.DENIED`

## 🧪 Testing Scenarios

### Test 1: Client ID Validation
**Objective**: Verify PayPal Client ID input validation

**Steps**:
1. Open: https://same-ybnqabs99nd-latest.netlify.app
2. Fill out quote form with test data
3. Try different Client ID formats:
   - **Invalid**: `short` (should show error)
   - **Invalid**: `invalid-chars-!@#$%` (should show error)
   - **Valid**: Your actual PayPal Client ID (should show ✓)

**Expected Results**:
- Short IDs rejected (< 20 characters)
- Invalid characters rejected
- Valid format accepted and saved to localStorage

### Test 2: PayPal SDK Loading
**Objective**: Test PayPal SDK loading with real Client ID

**Steps**:
1. Enter your valid PayPal Client ID
2. Watch the loading indicator
3. Check browser console for diagnostic messages
4. Verify PayPal buttons appear

**Expected Results**:
- Loading indicator shows progress
- PayPal SDK loads successfully
- PayPal payment buttons render
- No console errors

### Test 3: Payment Flow (Sandbox)
**Objective**: Complete end-to-end payment with sandbox

**Setup**:
- Use PayPal Sandbox Client ID
- Test credit card: 4111111111111111 (Visa)
- Test PayPal account: sb-test@personal.example.com / password

**Steps**:
1. Use sandbox Client ID
2. Complete quote form
3. Click PayPal button
4. Log in with test PayPal account OR use test card
5. Approve payment
6. Verify success page

**Expected Results**:
- Payment completes successfully
- Success callback triggered
- Email notification sent (if configured)
- Payment visible in PayPal sandbox dashboard

### Test 4: Email Notifications
**Objective**: Test payment confirmation emails

**Prerequisites**: EmailJS configured with environment variables

**Steps**:
1. Complete a test payment
2. Watch for email status indicators
3. Check recipient email inbox
4. Verify email content

**Expected Results**:
- "Sending email..." indicator appears
- "Email sent successfully!" confirmation
- Customer receives detailed payment confirmation
- Email includes all payment and service details

### Test 5: Error Handling
**Objective**: Test error scenarios and recovery

**Test Cases**:
1. **Invalid Client ID**: Use fake ID, verify error message
2. **Network Issues**: Disable network, test retry functionality
3. **Payment Cancellation**: Start payment, cancel in PayPal popup
4. **Payment Decline**: Use declined test card

**Expected Results**:
- Clear error messages for each scenario
- Retry functionality works
- No crashes or undefined states
- Diagnostic logs help troubleshooting

## 🔍 Monitoring & Debugging

### Diagnostic Logs
- Click "Show Diagnostics" to view detailed logs
- Monitor PayPal SDK loading process
- Track payment flow progression
- Email sending status

### Netlify Function Logs
1. Go to Netlify dashboard → Functions
2. Monitor `paypal-webhook` function logs
3. Check for webhook event processing
4. Verify payment data logging

### PayPal Dashboard
- Monitor payments in PayPal dashboard
- Verify payment amounts and status
- Check for any failed transactions

## 🚀 Live Testing Checklist

### Pre-Production
- [ ] Test with PayPal Sandbox environment
- [ ] Verify all payment flows work correctly
- [ ] Test email notifications
- [ ] Validate error handling
- [ ] Check webhook processing

### Production Deployment
- [ ] Switch to Live PayPal Client ID
- [ ] Update webhook URLs to production
- [ ] Test small amount payment ($1 CAD)
- [ ] Verify live email delivery
- [ ] Monitor for 24 hours

### Post-Deployment
- [ ] Customer can complete payments
- [ ] Emails arrive promptly
- [ ] No console errors
- [ ] PayPal dashboard shows payments
- [ ] Webhook events processed

## 🛠 Testing Functions

### Automated Testing
Visit: `/.netlify/functions/test-payment-flow`

This function provides:
- Test scenarios and cases
- Validation testing
- Environment information
- Detailed checklists

### Client ID Validation API
```bash
curl -X POST https://your-site.netlify.app/.netlify/functions/test-payment-flow \
  -H "Content-Type: application/json" \
  -d '{"test_type": "client_id_validation", "client_id": "YOUR_CLIENT_ID"}'
```

## 📞 Support & Troubleshooting

### Common Issues
1. **PayPal SDK Won't Load**
   - Verify Client ID format
   - Check network connectivity
   - Try refreshing the page

2. **Emails Not Sending**
   - Verify EmailJS environment variables
   - Check EmailJS dashboard for quota/errors
   - Ensure customer email is valid

3. **Webhooks Not Received**
   - Verify webhook URL in PayPal dashboard
   - Check Netlify function logs
   - Ensure HTTPS URL

### Debug Steps
1. Open browser developer tools
2. Check console for errors
3. Enable diagnostic logging
4. Monitor network requests
5. Verify function logs in Netlify

## 🎯 Success Criteria

### For Each Test Payment:
- ✅ Client ID validates correctly
- ✅ PayPal SDK loads without errors
- ✅ Payment buttons render properly
- ✅ Payment completes successfully
- ✅ Email notification sent
- ✅ Success page displays
- ✅ Payment appears in PayPal dashboard
- ✅ No console errors or warnings

## 📈 Production Monitoring

### Key Metrics to Track:
- Payment success rate
- Email delivery rate
- Average payment completion time
- Error rates by type
- Customer support tickets related to payments

### Regular Testing:
- Weekly test payments
- Monthly end-to-end flow verification
- Quarterly PayPal integration review
