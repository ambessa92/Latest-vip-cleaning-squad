exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod === 'POST') {
    try {
      const body = JSON.parse(event.body || '{}');
      return {
        statusCode: 200,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ success: true, message: 'Configuration saved' })
      };
    } catch (error) {
      return {
        statusCode: 500,
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ success: false, error: error.message })
      };
    }
  }

  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EmailJS Setup</title>
<style>
body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f5f5f5}
.container{max-width:800px;margin:0 auto;background:white;padding:30px;border-radius:12px;box-shadow:0 4px 6px rgba(0,0,0,0.1)}
.header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;padding:30px;margin:-30px -30px 30px -30px;border-radius:12px 12px 0 0;text-align:center}
.form-group{margin-bottom:20px}
label{display:block;font-weight:600;margin-bottom:8px;color:#333}
input{width:100%;padding:12px;border:2px solid #e1e1e1;border-radius:8px;font-size:14px;box-sizing:border-box}
input:focus{outline:none;border-color:#667eea}
.help-text{font-size:13px;color:#666;margin-top:5px}
.button{background:#667eea;color:white;border:none;padding:12px 24px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer}
.button:hover{background:#5a67d8}
.steps{background:#f7fafc;padding:20px;border-radius:8px;margin-bottom:25px}
.step{margin-bottom:10px;padding-left:20px;position:relative}
.step:before{content:counter(step);counter-increment:step;position:absolute;left:0;background:#667eea;color:white;width:16px;height:16px;border-radius:50%;font-size:11px;text-align:center;line-height:16px}
.steps{counter-reset:step}
.status{padding:15px;border-radius:8px;margin-bottom:20px;display:none}
.status.success{background:#f0fff4;border:1px solid #68d391;color:#22543d}
.status.error{background:#fed7d7;border:1px solid #e53e3e;color:#742a2a}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>📧 EmailJS Configuration</h1>
<p>Set up email notifications for payment confirmations</p>
</div>

<div id="status" class="status"></div>

<div class="steps">
<h3>🚀 Setup Steps</h3>
<div class="step">Go to <a href="https://www.emailjs.com" target="_blank">emailjs.com</a> and create account</div>
<div class="step">Add email service (Gmail recommended)</div>
<div class="step">Create email template with variables</div>
<div class="step">Copy IDs below and save</div>
</div>

<form id="config-form">
<div class="form-group">
<label>EmailJS Service ID</label>
<input type="text" id="service_id" placeholder="service_abc123" required>
<div class="help-text">From EmailJS Dashboard → Email Services</div>
</div>

<div class="form-group">
<label>EmailJS Template ID</label>
<input type="text" id="template_id" placeholder="template_xyz789" required>
<div class="help-text">From EmailJS Dashboard → Email Templates</div>
</div>

<div class="form-group">
<label>EmailJS User ID</label>
<input type="text" id="user_id" placeholder="user_abcdefghijklmnop" required>
<div class="help-text">From EmailJS Dashboard → Account</div>
</div>

<div class="form-group">
<label>From Name</label>
<input type="text" id="from_name" value="Hellamaid Services">
<div class="help-text">Name shown in emails</div>
</div>

<button type="submit" class="button">💾 Save Configuration</button>
</form>

<div style="margin-top:30px;padding-top:20px;border-top:1px solid #e1e1e1">
<h3>📖 Links</h3>
<p>
<a href="/.netlify/functions/payment-analytics?view=dashboard" target="_blank">📊 Analytics</a> |
<a href="https://www.emailjs.com/docs/" target="_blank">📚 EmailJS Docs</a> |
<a href="/" target="_blank">🧮 Calculator</a>
</p>
</div>
</div>

<script>
function showStatus(msg,type){
var s=document.getElementById('status');
s.textContent=msg;
s.className='status '+(type||'success');
s.style.display='block';
setTimeout(function(){s.style.display='none'},5000);
}

document.getElementById('config-form').addEventListener('submit',function(e){
e.preventDefault();
var config={
action:'save_emailjs_config',
service_id:document.getElementById('service_id').value,
template_id:document.getElementById('template_id').value,
user_id:document.getElementById('user_id').value,
from_name:document.getElementById('from_name').value
};

localStorage.setItem('emailjs_config',JSON.stringify(config));

fetch('/.netlify/functions/emailjs-admin',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify(config)
})
.then(function(r){return r.json()})
.then(function(result){
showStatus('✅ Configuration saved successfully!','success');
})
.catch(function(){
showStatus('✅ Configuration saved locally!','success');
});
});

try{
var saved=localStorage.getItem('emailjs_config');
if(saved){
var config=JSON.parse(saved);
document.getElementById('service_id').value=config.service_id||'';
document.getElementById('template_id').value=config.template_id||'';
document.getElementById('user_id').value=config.user_id||'';
document.getElementById('from_name').value=config.from_name||'Hellamaid Services';
}
}catch(e){}
</script>
</body>
</html>`;

  return {
    statusCode: 200,
    headers: { ...headers, 'Content-Type': 'text/html' },
    body: html
  };
};
