# 📅 Google Calendar Integration Setup Guide

This guide explains how to set up and use the Google Calendar integration for your cleaning service booking system.

## 🎯 What's Included

The Google Calendar integration provides:
- **Automatic event creation** after successful payment
- **Customer calendar invites** with booking details
- **Business calendar events** with comprehensive service information
- **Multiple reminders** (24 hours, 1 hour, 30 minutes before service)
- **Proper timezone handling** for the Niagara region
- **Error handling** that won't break the booking flow

## 🛠️ Setup Instructions

### 1. Google Cloud Console Setup

1. **Go to Google Cloud Console**: https://console.cloud.google.com/
2. **Create or select a project**
3. **Enable Google Calendar API**:
   - Go to "APIs & Services" > "Library"
   - Search for "Google Calendar API"
   - Click "Enable"

### 2. Create OAuth 2.0 Credentials

1. **Go to "APIs & Services" > "Credentials"**
2. **Click "Create Credentials" > "OAuth 2.0 Client IDs"**
3. **Configure OAuth consent screen** (if prompted):
   - Choose "External" for user type
   - Fill in app name, user support email, developer email
   - Add scopes: `https://www.googleapis.com/auth/calendar`
4. **Create OAuth 2.0 Client ID**:
   - Application type: "Web application"
   - Name: "Cleaning Service Calendar Integration"
   - Authorized redirect URIs: `http://localhost:5173` (for development)

### 3. Environment Configuration

1. **Copy the example environment file**:
   ```bash
   cp .env.example .env
   ```

2. **Add your Google Calendar credentials to `.env`**:
   ```env
   # Google Calendar Integration
   VITE_GOOGLE_CALENDAR_CLIENT_ID=your_client_id_here
   VITE_GOOGLE_CALENDAR_CLIENT_SECRET=your_client_secret_here
   VITE_GOOGLE_CALENDAR_REDIRECT_URI=http://localhost:5173
   VITE_GOOGLE_CALENDAR_ID=primary
   ```

3. **Replace `your_client_id_here` and `your_client_secret_here`** with your actual credentials

## 🧩 Integration Components

### Core Files

- **`src/services/googleCalendar.ts`**: Main calendar service with API integration
- **`src/components/CalendarIntegration.tsx`**: UI components for calendar features
- **`src/components/EnhancedPaymentForm.tsx`**: Updated with calendar integration
- **`src/components/GoogleCalendarPriceCalculator.tsx`**: Demo component showcasing integration

### Key Functions

```typescript
// Create calendar event for booking
const eventId = await createCalendarEvent(bookingDetails);

// Generate customer calendar link
const customerLink = createCustomerCalendarInvite(bookingDetails);

// Generate business calendar link
const businessLink = generateCalendarLink(bookingDetails);
```

## 🎨 User Experience

### For Customers
1. **Complete booking** through the normal flow
2. **See confirmation** with "Add to Calendar" button
3. **Click to add** appointment to their personal calendar
4. **Receive automatic reminders** before the service

### For Business
1. **Automatic calendar events** created for each booking
2. **Complete booking details** in event description
3. **Customer contact information** readily available
4. **Service reminders** for the team

## 📋 Calendar Event Details

Each calendar event includes:

```
🏠 CLEANING SERVICE BOOKING

📋 Booking Details:
• Booking Number: VCS123456
• Customer: John Doe
• Service Type: Residential
• Cleaning Type: Standard
• Frequency: Weekly
• Price: $120.00 CAD

📍 Service Location:
123 Main Street, St. Catharines
Area: St. Catharines

📞 Contact Information:
• Phone: (555) 123-4567
• Email: john@example.com

⏰ Scheduled: 2025-01-15 at 2:00 PM - 5:00 PM

📝 Notes:
- Confirm arrival time 30 minutes before service
- Contact customer if any scheduling conflicts arise
- Bring all necessary cleaning supplies and equipment
```

## 🔧 Technical Implementation

### Current Implementation (Demo Mode)
- Calendar events are **logged to console** with full details
- **Mock event IDs** are generated for demonstration
- **Calendar links** are fully functional
- **No actual Google API calls** are made (to avoid authentication complexity)

### Production Implementation
To enable live Google Calendar API calls:

1. **Implement OAuth flow** in `src/services/googleCalendar.ts`
2. **Replace mock event creation** with actual API calls
3. **Add user authentication** for calendar access
4. **Handle API errors** and rate limiting

### Sample Integration in Booking Flow

```typescript
// In payment success handler
const handlePaymentSuccess = async () => {
  // 1. Process payment
  await processPayment();

  // 2. Send confirmation email
  await sendConfirmationEmail();

  // 3. Create calendar event
  const eventId = await createCalendarEvent(bookingDetails);

  // 4. Show confirmation with calendar integration
  showConfirmation({ calendarEventId: eventId });
};
```

## 🚀 Features in Action

### Calendar Components
```jsx
// Simple calendar button
<CalendarButtons bookingDetails={bookingDetails} />

// Full calendar integration panel
<CalendarIntegration bookingDetails={bookingDetails} />
```

### Automatic Reminders
- **24 hours before**: Email reminder to customer
- **1 hour before**: Popup reminder
- **30 minutes before**: Final popup reminder

### Timezone Support
All events are created in `America/Toronto` timezone to match the Niagara region service area.

## 🔐 Security Considerations

- **Environment variables** keep credentials secure
- **OAuth 2.0** provides secure API access
- **Client-side integration** avoids server-side complexity
- **Graceful fallback** if calendar integration fails

## 📞 Support

If you need help setting up the Google Calendar integration:

1. **Check the console logs** for detailed diagnostic information
2. **Verify environment variables** are set correctly
3. **Ensure Google Calendar API** is enabled in your project
4. **Check OAuth consent screen** configuration

## 🎉 Benefits

✅ **Automated scheduling** reduces manual work
✅ **Customer convenience** with calendar reminders
✅ **Professional appearance** with detailed calendar events
✅ **Business efficiency** with organized appointment tracking
✅ **Reduced no-shows** through automatic reminders
✅ **Better customer experience** with seamless integration

The Google Calendar integration transforms your booking system into a comprehensive scheduling solution that benefits both your business and your customers!
