# VIP Cleaning Squad - Professional Cleaning Services

## 🚀 Live Website
- **Live URL**: https://your-domain-here.netlify.app
- **Phone**: (289) 697-6559
- **Email**: info@vipcleaningsquad.ca

## 🏗️ Quick Deploy to Netlify

### Method 1: Direct Upload
1. Download this repository as ZIP
2. Go to [Netlify Dashboard](https://app.netlify.com)
3. Drag & drop the ZIP file
4. Your site will be live!

### Method 2: GitHub Deploy
1. Push this code to your GitHub repository
2. Connect GitHub to Netlify
3. Select this repository
4. Set build command: `bun run build`
5. Set publish directory: `dist`

## 📋 Build Settings
- **Build Command**: `bun run build`
- **Publish Directory**: `dist`
- **Node Version**: 18

## 🔧 Environment Variables (Optional)
If you want payment processing, add these in Netlify:
- `PAYPAL_CLIENT_ID`
- `EMAILJS_PUBLIC_KEY`
- `EMAILJS_SERVICE_ID`
- `EMAILJS_TEMPLATE_ID`

## 🌐 Custom Domain Setup
1. Go to Site Settings → Domain Management
2. Add custom domain
3. Update DNS records
4. SSL automatically provisioned

## 📱 Features
- ✅ Professional VIP Cleaning Squad branding
- ✅ Interactive Niagara service coverage map
- ✅ Quote calculator with real-time pricing
- ✅ Mobile responsive design
- ✅ SEO optimized
- ✅ Contact forms and booking system

## 🏆 Ready for Business!
Your professional cleaning business website is ready to attract customers across the Niagara region.

---
 2024 VIP Cleaning Squad - Professional Cleaning Services
