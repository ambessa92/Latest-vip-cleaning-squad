import { useState, useEffect } from 'react';
import emailjs from '@emailjs/browser';
import EnhancedPaymentForm from './EnhancedPaymentForm';

interface PricingData {
  homeSize: string;
  bedrooms: string;
  bathrooms: string;
  cleaningType: string;
  frequency: string;
  extras: string[];
}

interface ContactInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
}

interface BookingDetails {
  date: string;
  time: string;
}

export default function PriceCalculator() {
  const [step, setStep] = useState(1);
  const [pricingData, setPricingData] = useState<PricingData>({
    homeSize: '',
    bedrooms: '',
    bathrooms: '',
    cleaningType: '',
    frequency: '',
    extras: []
  });
  const [contactInfo, setContactInfo] = useState<ContactInfo>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: ''
  });
  const [bookingDetails, setBookingDetails] = useState<BookingDetails>({
    date: '',
    time: ''
  });
  const [calculatedPrice, setCalculatedPrice] = useState(0);
  const [priceBreakdown, setPriceBreakdown] = useState<{[key: string]: number}>({});
  const [isCalculated, setIsCalculated] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [bookingNumber, setBookingNumber] = useState('');
  const [recentBookings, setRecentBookings] = useState([
    { name: 'Sarah M.', location: 'Toronto', time: '2 minutes ago', service: 'Deep Cleaning' },
    { name: 'Mike R.', location: 'Vancouver', time: '5 minutes ago', service: 'Standard Cleaning' },
    { name: 'Jennifer K.', location: 'Calgary', time: '8 minutes ago', service: 'Move-out Cleaning' },
    { name: 'David L.', location: 'Ottawa', time: '12 minutes ago', service: 'Deep Cleaning' },
    { name: 'Amanda C.', location: 'St. Catharines', time: '18 minutes ago', service: 'Bi-weekly Cleaning' },
    { name: 'Lisa P.', location: 'Montreal', time: '22 minutes ago', service: 'Standard Cleaning' }
  ]);
  const [currentBookingIndex, setCurrentBookingIndex] = useState(0);

  // Rotating recent bookings effect
  useEffect(() => {
    const bookingTimer = setInterval(() => {
      setCurrentBookingIndex((prev) => (prev + 1) % recentBookings.length);
    }, 180000); // 3 minutes = 180,000 milliseconds
    return () => clearInterval(bookingTimer);
  }, [recentBookings]);

  const homeSizeOptions = [
    { value: 'studio', label: '🏠 Studio (up to 600 sq ft)', price: 80, originalPrice: 95 },
    { value: 'one-bedroom', label: '🏡 1 Bedroom (600-900 sq ft)', price: 100, originalPrice: 120 },
    { value: 'two-bedroom', label: '🏘️ 2 Bedroom (900-1200 sq ft)', price: 120, originalPrice: 145 },
    { value: 'three-bedroom', label: '🏠 3 Bedroom (1200-1600 sq ft)', price: 150, originalPrice: 180 },
    { value: 'four-bedroom', label: '🏰 4 Bedroom (1600-2200 sq ft)', price: 180, originalPrice: 220 },
    { value: 'five-bedroom', label: '🏛️ 5+ Bedroom (2200+ sq ft)', price: 220, originalPrice: 270 }
  ];

  const bedroomOptions = [
    { value: '0', label: '0 Bedrooms', price: 0 },
    { value: '1', label: '1 Bedroom', price: 15 },
    { value: '2', label: '2 Bedrooms', price: 25 },
    { value: '3', label: '3 Bedrooms', price: 35 },
    { value: '4', label: '4 Bedrooms', price: 45 },
    { value: '5+', label: '5+ Bedrooms', price: 60 }
  ];

  const bathroomOptions = [
    { value: '1', label: '1 Bathroom', price: 0 },
    { value: '1.5', label: '1.5 Bathrooms', price: 10 },
    { value: '2', label: '2 Bathrooms', price: 20 },
    { value: '2.5', label: '2.5 Bathrooms', price: 30 },
    { value: '3', label: '3 Bathrooms', price: 40 },
    { value: '3.5', label: '3.5 Bathrooms', price: 50 },
    { value: '4+', label: '4+ Bathrooms', price: 60 }
  ];

  const cleaningTypeOptions = [
    { value: 'standard', label: '🧹 Standard Cleaning', multiplier: 1.0, popular: false, badge: '' },
    { value: 'deep', label: '🧽 Deep Cleaning', multiplier: 1.5, popular: true, badge: '🌟 MOST POPULAR' },
    { value: 'move-in', label: '📦 Move-in Cleaning', multiplier: 1.4, popular: false, badge: '🔥 TRENDING' },
    { value: 'move-out', label: '🚚 Move-out Cleaning', multiplier: 1.4, popular: false, badge: '' },
    { value: 'post-construction', label: '🏗️ Post-Construction', multiplier: 2.0, popular: false, badge: '💎 PREMIUM' }
  ];

  const frequencyOptions = [
    { value: 'one-time', label: '⭐ One-time', discount: 0, badge: '', savings: 0 },
    { value: 'weekly', label: '📅 Weekly', discount: 0.15, badge: 'SAVE 15%', savings: 240 },
    { value: 'bi-weekly', label: '📆 Bi-weekly', discount: 0.10, badge: 'SAVE 10%', savings: 156 },
    { value: 'monthly', label: '🗓️ Monthly', discount: 0.05, badge: 'SAVE 5%', savings: 78 }
  ];

  const extrasOptions = [
    { value: 'inside-fridge', label: '❄️ Inside Fridge', price: 25, popular: true },
    { value: 'inside-oven', label: '🔥 Inside Oven', price: 25, popular: true },
    { value: 'inside-microwave', label: '📱 Inside Microwave', price: 15, popular: false },
    { value: 'inside-cabinets', label: '🗄️ Inside Cabinets', price: 40, popular: false },
    { value: 'windows-interior', label: '🪟 Interior Windows', price: 30, popular: true },
    { value: 'baseboards', label: '🧽 Baseboards', price: 20, popular: false },
    { value: 'garage', label: '🚗 Garage', price: 50, popular: false },
    { value: 'laundry', label: '👕 Laundry', price: 30, popular: false }
  ];

  const testimonials = [
    { name: 'Sarah Johnson', location: 'Toronto, ON', rating: 5, text: 'Absolutely amazing! My house has never been this clean. The team was professional and thorough.', service: 'Deep Cleaning', verified: true },
    { name: 'Michael Chen', location: 'Vancouver, BC', rating: 5, text: 'Best cleaning service in the city! They even cleaned areas I forgot existed. Highly recommend!', service: 'Standard Cleaning', verified: true },
    { name: 'Emma Rodriguez', location: 'Calgary, AB', rating: 5, text: 'Saved me so much time and stress during my move. Worth every penny!', service: 'Move-out Cleaning', verified: true },
    { name: 'David Kim', location: 'Ottawa, ON', rating: 5, text: 'Professional, reliable, and affordable. Been using them for 6 months now!', service: 'Bi-weekly Cleaning', verified: true }
  ];

  const calculatePrice = () => {
    const basePrice = homeSizeOptions.find(option => option.value === pricingData.homeSize)?.price || 0;
    const bedroomPrice = bedroomOptions.find(option => option.value === pricingData.bedrooms)?.price || 0;
    const bathroomPrice = bathroomOptions.find(option => option.value === pricingData.bathrooms)?.price || 0;
    const cleaningMultiplier = cleaningTypeOptions.find(option => option.value === pricingData.cleaningType)?.multiplier || 1.0;
    const frequencyDiscount = frequencyOptions.find(option => option.value === pricingData.frequency)?.discount || 0;

    const extrasPrice = pricingData.extras.reduce((total, extra) => {
      const extraOption = extrasOptions.find(option => option.value === extra);
      return total + (extraOption?.price || 0);
    }, 0);

    const subtotal = (basePrice + bedroomPrice + bathroomPrice) * cleaningMultiplier;
    const discount = subtotal * frequencyDiscount;
    const finalPrice = subtotal - discount + extrasPrice;

    const breakdown = {
      'Base Price': basePrice,
      'Bedrooms': bedroomPrice,
      'Bathrooms': bathroomPrice,
      'Cleaning Type': subtotal - (basePrice + bedroomPrice + bathroomPrice),
      'Extras': extrasPrice,
      'Frequency Discount': -discount,
      'FREE Sanitization': -25
    };

    setPriceBreakdown(breakdown);
    setCalculatedPrice(finalPrice - 25); // Apply free sanitization
    setIsCalculated(true);
  };

  const handleExtrasChange = (extraValue: string) => {
    setPricingData(prev => ({
      ...prev,
      extras: prev.extras.includes(extraValue)
        ? prev.extras.filter(extra => extra !== extraValue)
        : [...prev.extras, extraValue]
    }));
  };

  const handleNextStep = () => {
    if (step === 1 && !isCalculated) {
      calculatePrice();
    }
    setStep(step + 1);
  };

  const handlePaymentSuccess = async () => {
    const newBookingNumber = `BK${Date.now()}`;
    setBookingNumber(newBookingNumber);
    setPaymentSuccess(true);

    // Send email notification
    await sendEmailNotification(newBookingNumber);
    setStep(5);
  };

  const sendEmailNotification = async (bookingNum: string) => {
    const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
    const templateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
    const userId = import.meta.env.VITE_EMAILJS_USER_ID;

    if (!serviceId || !templateId || !userId) {
      console.error('EmailJS configuration missing');
      return;
    }

    try {
      await emailjs.send(serviceId, templateId, {
        booking_number: bookingNum,
        customer_name: `${contactInfo.firstName} ${contactInfo.lastName}`,
        customer_email: contactInfo.email,
        customer_phone: contactInfo.phone,
        service_date: bookingDetails.date,
        service_time: bookingDetails.time,
        service_address: `${contactInfo.address}, ${contactInfo.city}, ${contactInfo.state} ${contactInfo.zipCode}`,
        cleaning_type: cleaningTypeOptions.find(option => option.value === pricingData.cleaningType)?.label || pricingData.cleaningType,
        frequency: frequencyOptions.find(option => option.value === pricingData.frequency)?.label || pricingData.frequency,
        total_price: calculatedPrice.toFixed(2),
        special_instructions: pricingData.extras.map(extra =>
          extrasOptions.find(option => option.value === extra)?.label || extra
        ).join(', ')
      }, userId);
    } catch (error) {
      console.error('Failed to send email:', error);
    }
  };

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour <= 17; hour += 3) {
      const endHour = Math.min(hour + 3, 20);
      const startTime = hour === 12 ? '12:00 PM' : hour > 12 ? `${hour - 12}:00 PM` : `${hour}:00 AM`;
      const endTime = endHour === 12 ? '12:00 PM' : endHour > 12 ? `${endHour - 12}:00 PM` : `${endHour}:00 AM`;
      slots.push(`${startTime} - ${endTime}`);
    }
    return slots;
  };

  const renderStep1 = () => (
    <div className="bg-white p-8 rounded-lg shadow-2xl max-w-2xl mx-auto border-4 border-yellow-300">

      {/* Social Proof & Authority Header */}
      <div className="text-center mb-6">
        <div className="bg-gradient-to-r from-green-100 to-blue-100 border-2 border-green-400 rounded-lg p-4 mb-4">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="text-2xl">🔥</span>
            <span className="text-red-600 font-bold text-lg">LIMITED TIME:</span>
            <span className="text-green-700 font-bold">FREE sanitization (worth $25)</span>
            <span className="text-2xl">🔥</span>
          </div>
          <div className="bg-yellow-200 rounded-full px-4 py-2 inline-block">
            <span className="font-bold text-gray-800">+ FREE re-cleaning if not 100% satisfied!</span>
          </div>
        </div>

        {/* Authority Badges */}
        <div className="flex justify-center items-center gap-6 text-sm text-gray-700 mb-4 flex-wrap">
          <div className="flex items-center bg-blue-50 px-3 py-2 rounded-full border border-blue-200">
            <span className="text-blue-600 mr-1">🛡️</span>
            <span className="font-semibold">Fully Insured & Bonded</span>
          </div>
          <div className="flex items-center bg-green-50 px-3 py-2 rounded-full border border-green-200">
            <span className="text-green-600 mr-1">✅</span>
            <span className="font-semibold">Background Checked</span>
          </div>
          <div className="flex items-center bg-purple-50 px-3 py-2 rounded-full border border-purple-200">
            <span className="text-purple-600 mr-1">🏆</span>
            <span className="font-semibold">Award Winning</span>
          </div>
        </div>

        {/* Social Proof */}
        <div className="flex justify-center items-center gap-4 text-sm text-gray-600 mb-4">
          <div className="flex items-center bg-green-50 px-4 py-2 rounded-full border border-green-200">
            <span className="text-green-500 mr-2">⭐⭐⭐⭐⭐</span>
            <span className="font-semibold">4.9/5 from 2,847+ customers</span>
          </div>
          <div className="flex items-center bg-green-50 px-4 py-2 rounded-full border border-green-200">
            <span className="text-green-500 mr-2">📈</span>
            <span className="font-semibold">15,000+ homes cleaned</span>
          </div>
        </div>

        {/* Live Social Proof */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 mb-4">
          <div className="flex items-center justify-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-gray-700">
              <strong>{recentBookings[currentBookingIndex].name}</strong> from {recentBookings[currentBookingIndex].location} just booked {recentBookings[currentBookingIndex].service}
              <span className="text-green-600 font-semibold"> {recentBookings[currentBookingIndex].time}</span>
            </span>
          </div>
        </div>
      </div>

      <h2 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
        ✨ Get Your Instant Quote - Takes 30 Seconds
      </h2>

      <div className="space-y-6">
        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">
            🏠 Home Size <span className="text-red-500 text-sm">(Special pricing - save up to $50!)</span>
          </label>
          <select
            value={pricingData.homeSize}
            onChange={(e) => setPricingData({...pricingData, homeSize: e.target.value})}
            className="w-full p-4 border-2 border-gray-300 rounded-lg focus:ring-4 focus:ring-yellow-200 focus:border-yellow-500 text-lg"
          >
            <option value="">Select your home size</option>
            {homeSizeOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label} - $<span style={{textDecoration: 'line-through'}}>{option.originalPrice}</span> ${option.price}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">🛏️ Bedrooms</label>
          <select
            value={pricingData.bedrooms}
            onChange={(e) => setPricingData({...pricingData, bedrooms: e.target.value})}
            className="w-full p-4 border-2 border-gray-300 rounded-lg focus:ring-4 focus:ring-yellow-200 focus:border-yellow-500 text-lg"
          >
            <option value="">Select number of bedrooms</option>
            {bedroomOptions.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">🚿 Bathrooms</label>
          <select
            value={pricingData.bathrooms}
            onChange={(e) => setPricingData({...pricingData, bathrooms: e.target.value})}
            className="w-full p-4 border-2 border-gray-300 rounded-lg focus:ring-4 focus:ring-yellow-200 focus:border-yellow-500 text-lg"
          >
            <option value="">Select number of bathrooms</option>
            {bathroomOptions.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">🧹 Cleaning Type</label>
          <div className="grid grid-cols-1 gap-3">
            {cleaningTypeOptions.map(option => (
              <label key={option.value} className={`relative flex items-center justify-between p-4 border-2 rounded-lg cursor-pointer transition-all ${
                pricingData.cleaningType === option.value
                  ? 'border-yellow-500 bg-yellow-50 shadow-lg'
                  : 'border-gray-200 hover:bg-gray-50 hover:border-gray-300'
              }`}>
                <div className="flex items-center">
                  <input
                    type="radio"
                    name="cleaningType"
                    value={option.value}
                    checked={pricingData.cleaningType === option.value}
                    onChange={(e) => setPricingData({...pricingData, cleaningType: e.target.value})}
                    className="mr-3 h-5 w-5 text-yellow-600 focus:ring-yellow-500"
                  />
                  <span className="text-lg font-medium">{option.label}</span>
                </div>
                {option.badge && (
                  <span className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                    {option.badge}
                  </span>
                )}
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">
            📅 Frequency <span className="text-green-600">(Save More With Regular Service!)</span>
          </label>
          <div className="grid grid-cols-1 gap-3">
            {frequencyOptions.map(option => (
              <label key={option.value} className={`flex items-center justify-between p-4 border-2 rounded-lg cursor-pointer transition-all ${
                pricingData.frequency === option.value
                  ? 'border-yellow-500 bg-yellow-50 shadow-lg'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}>
                <div className="flex items-center">
                  <input
                    type="radio"
                    name="frequency"
                    value={option.value}
                    checked={pricingData.frequency === option.value}
                    onChange={(e) => setPricingData({...pricingData, frequency: e.target.value})}
                    className="mr-3 h-5 w-5 text-yellow-600 focus:ring-yellow-500"
                  />
                  <div>
                    <span className="text-lg font-medium">{option.label}</span>
                    {option.savings > 0 && (
                      <div className="text-sm text-green-600 font-semibold">
                        Save up to ${option.savings}/year!
                      </div>
                    )}
                  </div>
                </div>
                {option.badge && (
                  <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                    {option.badge}
                  </span>
                )}
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-lg font-bold text-gray-700 mb-3">
            ✨ Additional Services <span className="text-sm text-gray-500">(Optional - Add More Value)</span>
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {extrasOptions.map(option => (
              <label key={option.value} className={`relative flex items-center p-3 border-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-all ${
                option.popular ? 'border-orange-300 bg-orange-50' : 'border-gray-200'
              }`}>
                <input
                  type="checkbox"
                  checked={pricingData.extras.includes(option.value)}
                  onChange={() => handleExtrasChange(option.value)}
                  className="mr-3 h-5 w-5 text-yellow-600 focus:ring-yellow-500 border-gray-300 rounded"
                />
                <span className="text-sm font-medium">{option.label} (+${option.price})</span>
                {option.popular && (
                  <span className="absolute -top-2 -right-2 bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                    POPULAR
                  </span>
                )}
              </label>
            ))}
          </div>
        </div>

        {isCalculated && (
          <div className="mt-6 p-6 bg-gradient-to-br from-yellow-50 via-green-50 to-blue-50 border-4 border-yellow-300 rounded-lg shadow-2xl">
            <div className="text-center mb-4">
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="text-3xl">🎉</span>
                <h3 className="text-3xl font-bold text-green-600">Your Instant Quote is Ready!</h3>
                <span className="text-3xl">🎉</span>
              </div>
              <p className="text-green-600 font-bold text-lg">Special pricing available today!</p>
            </div>

            <div className="bg-white p-6 rounded-lg mb-6 shadow-lg border-2 border-gray-200">
              {Object.entries(priceBreakdown).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center mb-3 text-lg">
                  <span className="text-gray-700 font-medium">{key}:</span>
                  <span className={value < 0 ? "text-green-600 font-bold" : "text-gray-900 font-semibold"}>
                    {value < 0 ? '-' : ''}${Math.abs(value).toFixed(2)}
                  </span>
                </div>
              ))}
              <div className="border-t-4 border-gray-300 pt-4 mt-4">
                <div className="flex justify-between items-center text-3xl font-bold">
                  <span>Total:</span>
                  <span className="text-green-600">${calculatedPrice.toFixed(2)}</span>
                </div>
                <div className="text-center text-sm text-gray-600 mt-2">
                  <span className="line-through">${(calculatedPrice + 50).toFixed(2)}</span>
                  <span className="ml-2 text-red-600 font-bold">YOU SAVE $50!</span>
                </div>
              </div>
            </div>

            {/* Trust Signals */}
            <div className="grid grid-cols-3 gap-2 text-center text-sm text-gray-700 mb-6">
              <div className="bg-green-100 p-3 rounded-lg border border-green-200">
                <div className="text-green-600 text-xl mb-1">✓</div>
                <div className="font-bold">100% Satisfaction Guarantee</div>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg border border-blue-200">
                <div className="text-blue-600 text-xl mb-1">⚡</div>
                <div className="font-bold">Same-Day Booking Available</div>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg border border-purple-200">
                <div className="text-purple-600 text-xl mb-1">🔄</div>
                <div className="font-bold">Cancel Anytime Free</div>
              </div>
            </div>

            {/* Testimonial */}
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <span className="text-green-500">⭐⭐⭐⭐⭐</span>
                </div>
                <div className="ml-3">
                  <p className="text-sm italic">"{testimonials[0].text}"</p>
                  <p className="text-xs text-gray-600 mt-1">
                    - {testimonials[0].name}, {testimonials[0].location}
                    {testimonials[0].verified && <span className="text-green-600 ml-1">✓ Verified</span>}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={isCalculated ? handleNextStep : calculatePrice}
          disabled={!pricingData.homeSize || !pricingData.bedrooms || !pricingData.bathrooms || !pricingData.cleaningType || !pricingData.frequency}
          className="w-full bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 text-white py-6 px-8 rounded-lg font-bold text-xl hover:from-yellow-500 hover:via-orange-500 hover:to-red-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 shadow-2xl border-4 border-yellow-300"
        >
          {isCalculated ? '🚀 SECURE THIS RATE - BOOK NOW' : '⚡ GET MY INSTANT QUOTE (FREE)'}
        </button>

        {/* Risk Reversal */}
        <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-4 text-center">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-700">
            <div>
              <span className="text-green-600 font-bold">🔒 No hidden fees</span> •
              <span className="text-blue-600 font-bold"> No commitment</span> •
              <span className="text-purple-600 font-bold"> No credit card required for quote</span>
            </div>
            <div>
              <span className="text-orange-600 font-bold">💰 Price Match Guarantee:</span>
              <span> Found a better quote? We'll match it + give you 10% off!</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-600">
            ✓ 100% Satisfaction Guarantee • ✓ Cancel Anytime Free • ✓ Fully Insured & Bonded
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
      {/* Price reminder */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-4 mb-6 text-center">
        <div className="flex items-center justify-center gap-2">
          <span className="text-xl">💰</span>
          <span className="font-bold">Your special rate: ${calculatedPrice.toFixed(2)}</span>
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-6 text-center">📞 Contact Information</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
          <input
            type="text"
            value={contactInfo.firstName}
            onChange={(e) => setContactInfo({...contactInfo, firstName: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="John"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
          <input
            type="text"
            value={contactInfo.lastName}
            onChange={(e) => setContactInfo({...contactInfo, lastName: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="Doe"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
          <input
            type="email"
            value={contactInfo.email}
            onChange={(e) => setContactInfo({...contactInfo, email: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="john@example.com"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
          <input
            type="tel"
            value={contactInfo.phone}
            onChange={(e) => setContactInfo({...contactInfo, phone: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="(555) 123-4567"
          />
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
        <input
          type="text"
          value={contactInfo.address}
          onChange={(e) => setContactInfo({...contactInfo, address: e.target.value})}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
          placeholder="123 Main Street"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
          <input
            type="text"
            value={contactInfo.city}
            onChange={(e) => setContactInfo({...contactInfo, city: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="Toronto"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">State/Province</label>
          <input
            type="text"
            value={contactInfo.state}
            onChange={(e) => setContactInfo({...contactInfo, state: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="ON"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Zip/Postal Code</label>
          <input
            type="text"
            value={contactInfo.zipCode}
            onChange={(e) => setContactInfo({...contactInfo, zipCode: e.target.value})}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="M5V 3A1"
          />
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => setStep(1)}
          className="flex-1 bg-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
        >
          ← Back
        </button>
        <button
          onClick={handleNextStep}
          disabled={!contactInfo.firstName || !contactInfo.lastName || !contactInfo.email || !contactInfo.phone || !contactInfo.address || !contactInfo.city || !contactInfo.state || !contactInfo.zipCode}
          className="flex-1 bg-yellow-400 text-gray-800 py-3 px-6 rounded-lg font-bold hover:bg-yellow-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          📅 Select Date & Time →
        </button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">📅 Select Date & Time</h2>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Service Date</label>
        <input
          type="date"
          value={bookingDetails.date}
          onChange={(e) => setBookingDetails({...bookingDetails, date: e.target.value})}
          min={new Date().toISOString().split('T')[0]}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
        />
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Time Slot</label>
        <div className="grid grid-cols-1 gap-3">
          {generateTimeSlots().map((slot) => (
            <label key={slot} className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
              <input
                type="radio"
                name="timeSlot"
                value={slot}
                checked={bookingDetails.time === slot}
                onChange={(e) => setBookingDetails({...bookingDetails, time: e.target.value})}
                className="mr-3 h-4 w-4 text-yellow-600 focus:ring-yellow-500 border-gray-300"
              />
              <span>{slot}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => setStep(2)}
          className="flex-1 bg-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
        >
          ← Back
        </button>
        <button
          onClick={handleNextStep}
          disabled={!bookingDetails.date || !bookingDetails.time}
          className="flex-1 bg-yellow-400 text-gray-800 py-3 px-6 rounded-lg font-bold hover:bg-yellow-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          💳 Proceed to Payment →
        </button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">💳 Secure Your Booking</h2>

      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">Booking Summary</h3>
        <p><strong>Service:</strong> {cleaningTypeOptions.find(option => option.value === pricingData.cleaningType)?.label}</p>
        <p><strong>Date:</strong> {new Date(bookingDetails.date).toLocaleDateString()}</p>
        <p><strong>Time:</strong> {bookingDetails.time}</p>
        <p><strong>Address:</strong> {contactInfo.address}, {contactInfo.city}, {contactInfo.state}</p>
        <p><strong>Total:</strong> ${calculatedPrice.toFixed(2)}</p>
      </div>

      <EnhancedPaymentForm
        amount={calculatedPrice}
        customerDetails={{
          name: `${contactInfo.firstName} ${contactInfo.lastName}`,
          email: contactInfo.email,
          phone: contactInfo.phone,
          address: contactInfo.address,
          city: contactInfo.city,
          state: contactInfo.state,
          zipCode: contactInfo.zipCode
        }}
        serviceDetails={{
          serviceType: cleaningTypeOptions.find(option => option.value === pricingData.cleaningType)?.label || pricingData.cleaningType,
          frequency: frequencyOptions.find(option => option.value === pricingData.frequency)?.label || pricingData.frequency,
          addOns: pricingData.extras.map(extra =>
            extrasOptions.find(option => option.value === extra)?.label || extra
          )
        }}
        onPaymentSuccess={handlePaymentSuccess}
        onPaymentError={(error) => console.error('Payment error:', error)}
      />

      <div className="mt-6">
        <button
          onClick={() => setStep(3)}
          className="w-full bg-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
        >
          ← Back to Date Selection
        </button>
      </div>
    </div>
  );

  const renderStep5 = () => (
    <div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto text-center">
      <div className="text-6xl mb-4">🎉</div>
      <h2 className="text-3xl font-bold mb-6 text-green-600">Booking Confirmed!</h2>

      <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
        <p className="text-lg mb-2"><strong>Booking Number:</strong> {bookingNumber}</p>
        <p className="text-gray-700">We've sent a confirmation email to {contactInfo.email}</p>
      </div>

      <div className="text-left space-y-2 mb-6">
        <p><strong>Service:</strong> {cleaningTypeOptions.find(option => option.value === pricingData.cleaningType)?.label}</p>
        <p><strong>Date:</strong> {new Date(bookingDetails.date).toLocaleDateString()}</p>
        <p><strong>Time:</strong> {bookingDetails.time}</p>
        <p><strong>Address:</strong> {contactInfo.address}, {contactInfo.city}, {contactInfo.state}</p>
        <p><strong>Total Paid:</strong> ${calculatedPrice.toFixed(2)}</p>
      </div>

      <button
        onClick={() => {
          setStep(1);
          setPricingData({ homeSize: '', bedrooms: '', bathrooms: '', cleaningType: '', frequency: '', extras: [] });
          setContactInfo({ firstName: '', lastName: '', email: '', phone: '', address: '', city: '', state: '', zipCode: '' });
          setBookingDetails({ date: '', time: '' });
          setCalculatedPrice(0);
          setIsCalculated(false);
          setPaymentSuccess(false);
          setBookingNumber('');
        }}
        className="bg-yellow-400 text-gray-800 py-3 px-6 rounded-lg font-bold hover:bg-yellow-500 transition-colors"
      >
        Book Another Service
      </button>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Progress indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4">
            {[1, 2, 3, 4, 5].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  step >= stepNumber ? 'bg-yellow-400 text-gray-800' : 'bg-gray-200 text-gray-500'
                }`}>
                  {stepNumber}
                </div>
                {stepNumber < 5 && (
                  <div className={`w-8 h-1 ${step > stepNumber ? 'bg-yellow-400' : 'bg-gray-200'}`}></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
        {step === 4 && renderStep4()}
        {step === 5 && renderStep5()}
      </div>
    </div>
  );
}
