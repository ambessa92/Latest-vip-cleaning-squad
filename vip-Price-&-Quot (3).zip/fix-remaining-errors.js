const fs = require('fs');
const path = require('path');

console.log('🔧 Fixing remaining TypeScript errors...');

// Fix CustomerDashboard.tsx - restore proper imports and structure
function fixCustomerDashboardImports() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/components/CustomerDashboard.tsx');

  if (!fs.existsSync(filePath)) {
    console.error('❌ CustomerDashboard.tsx not found');
    return;
  }

  // Read the original file from user attachment to restore proper structure
  const originalContent = `import type React from 'react';
import { useState, useEffect } from 'react';
import {
  CustomerAuthService,
  SubscriptionService,
  PaymentService,
  ServiceHistoryService,
  type Customer,
  type Subscription,
  type Payment,
  type ServiceHistory,
  type RegistrationData,
  ValidationService,
  SECURITY_QUESTIONS
} from '../services/customerAccount';
import { NotificationCenter } from './NotificationCenter';
import { NotificationService } from '../services/notifications';`;

  let content = fs.readFileSync(filePath, 'utf8');

  // If the file doesn't start with proper imports, restore them
  if (!content.includes('import type React from')) {
    // Find where the rest of the file content starts
    const contentStart = content.indexOf('const PaymentsTab');
    if (contentStart > 0) {
      const restOfFile = content.substring(contentStart);
      content = originalContent + '\n\n// Customer Dashboard Types\n\n' + restOfFile;
    }
  }

  // Ensure proper default export at the end
  if (!content.includes('export default CustomerDashboard')) {
    content += '\n\nexport default CustomerDashboard;\n';
  }

  fs.writeFileSync(filePath, content);
  console.log('✅ Fixed CustomerDashboard.tsx imports and exports');
}

// Fix OrderData interface mismatch in EnhancedPaymentForm
function fixOrderDataMismatch() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/components/EnhancedPaymentForm.tsx');

  if (!fs.existsSync(filePath)) {
    console.error('❌ EnhancedPaymentForm.tsx not found');
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');

  // Fix the sendConfirmationEmail calls to match OrderData interface
  content = content.replace(
    /await sendConfirmationEmail\(order\);/g,
    'await sendConfirmationEmail({ ...order, orderID: order.id });'
  );

  content = content.replace(
    /await createCalendarEventForBooking\(order\);/g,
    'await createCalendarEventForBooking({ ...order, orderID: order.id });'
  );

  // Fix customerId type issue (string | null to string | undefined)
  content = content.replace(
    /customerId,/g,
    'customerId: customerId || undefined,'
  );

  fs.writeFileSync(filePath, content);
  console.log('✅ Fixed OrderData interface mismatches');
}

// Remove or fix the subscriptionManagement.ts file that's causing issues
function fixSubscriptionManagement() {
  const filePath = path.join(__dirname, 'hellamaid-quote-system/src/services/subscriptionManagement.ts');

  if (fs.existsSync(filePath)) {
    // This file seems to be conflicting with our main implementation
    // Let's remove it or fix the critical errors
    let content = fs.readFileSync(filePath, 'utf8');

    // Fix the pausedUntil vs pauseUntil issue
    content = content.replace(/pausedUntil/g, 'pauseUntil');

    // Fix the RetentionOffer type issue
    content = content.replace(
      /type: 'discount'/g,
      "type: 'discount' as const"
    );
    content = content.replace(
      /type: 'pause'/g,
      "type: 'pause' as const"
    );
    content = content.replace(
      /type: 'upgrade'/g,
      "type: 'upgrade' as const"
    );

    // Fix the event.resource.id issue
    content = content.replace(
      /event\.resource\.id \|\| 'unknown'/g,
      "(event.resource as any).id || 'unknown'"
    );

    fs.writeFileSync(filePath, content);
    console.log('✅ Fixed subscriptionManagement.ts type issues');
  }
}

// Run all fixes
try {
  fixCustomerDashboardImports();
  fixOrderDataMismatch();
  fixSubscriptionManagement();

  console.log('\n🎉 Remaining TypeScript errors fixed!');

} catch (error) {
  console.error('❌ Error applying fixes:', error);
}
