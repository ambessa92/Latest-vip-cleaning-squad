const puppeteer = require('puppeteer');
const fs = require('fs');

async function testBookingFlow() {
    console.log('Starting booking flow test...');
    
    const browser = await puppeteer.launch({ 
        headless: false,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1200, height: 800 });
    
    try {
        // Navigate to the application
        console.log('1. Navigating to the application...');
        await page.goto('https://same-ybnqabs99nd-latest.netlify.app', { 
            waitUntil: 'networkidle2',
            timeout: 30000 
        });
        
        // Take initial screenshot
        await page.screenshot({ path: 'screenshots/01_initial_page.png', fullPage: true });
        console.log('✓ Initial page screenshot saved');
        
        // Fill out contact information
        console.log('2. Filling out contact information...');
        await page.waitForSelector('input[placeholder="Full Name"]', { timeout: 10000 });
        await page.type('input[placeholder="Full Name"]', 'John Smith');
        await page.type('input[placeholder="email@example.com"]', 'john.smith@example.com');
        await page.type('input[placeholder="(555) 123-4567"]', '(555) 123-4567');
        
        // Select home size
        console.log('3. Selecting home size...');
        await page.select('select[name="homeSize"]', 'medium');
        
        // Select bedrooms
        console.log('4. Selecting bedrooms...');
        await page.select('select[name="bedrooms"]', '3');
        
        // Select bathrooms
        console.log('5. Selecting bathrooms...');
        await page.select('select[name="bathrooms"]', '2');
        
        // Select half baths
        console.log('6. Selecting half baths...');
        await page.select('select[name="halfBaths"]', '1');
        
        // Select additional services
        console.log('7. Selecting additional services...');
        await page.check('input[value="insideFridge"]');
        await page.check('input[value="windows"]');
        
        // Take screenshot before calculation
        await page.screenshot({ path: 'screenshots/02_form_filled.png', fullPage: true });
        console.log('✓ Form filled screenshot saved');
        
        // Submit the form
        console.log('8. Submitting the form...');
        await page.click('button[type="submit"]');
        
        // Wait for price calculation results
        await page.waitForTimeout(2000);
        await page.screenshot({ path: 'screenshots/03_price_calculated.png', fullPage: true });
        console.log('✓ Price calculation screenshot saved');
        
        // Look for continue/proceed button to go to next step
        console.log('9. Looking for next step button...');
        
        // Try to find and click a button that proceeds to booking/scheduling
        const proceedSelectors = [
            'button:contains("Book Now")',
            'button:contains("Continue")',
            'button:contains("Proceed")',
            'button:contains("Schedule")',
            '.book-now-btn',
            '.proceed-btn',
            '.continue-btn'
        ];
        
        let proceedButton = null;
        for (const selector of proceedSelectors) {
            try {
                proceedButton = await page.$(selector);
                if (proceedButton) {
                    console.log(`Found proceed button with selector: ${selector}`);
                    break;
                }
            } catch (e) {
                // Continue to next selector
            }
        }
        
        if (proceedButton) {
            await proceedButton.click();
            await page.waitForTimeout(2000);
            await page.screenshot({ path: 'screenshots/04_after_proceed.png', fullPage: true });
            console.log('✓ After proceed screenshot saved');
        }
        
        // Try to navigate to payment page
        console.log('10. Looking for payment page...');
        
        // Look for payment-related elements or forms
        const paymentSelectors = [
            '.stripe-payment-form',
            '.payment-form',
            '.StripePaymentForm',
            'form[data-testid="payment-form"]',
            '.payment-methods',
            '.payment-options'
        ];
        
        let paymentFound = false;
        for (const selector of paymentSelectors) {
            try {
                const element = await page.$(selector);
                if (element) {
                    console.log(`Found payment element with selector: ${selector}`);
                    paymentFound = true;
                    break;
                }
            } catch (e) {
                // Continue to next selector
            }
        }
        
        if (paymentFound) {
            await page.screenshot({ path: 'screenshots/05_payment_page.png', fullPage: true });
            console.log('✓ Payment page screenshot saved');
            
            // Look for Apple Pay and Google Pay buttons
            console.log('11. Looking for Apple Pay and Google Pay options...');
            
            // Wait for payment request button to potentially appear
            await page.waitForTimeout(3000);
            
            // Check for digital wallet buttons
            const walletSelectors = [
                '.apple-pay-button',
                '.google-pay-button',
                '.payment-request-button',
                '[data-testid="apple-pay"]',
                '[data-testid="google-pay"]',
                'button:contains("Apple Pay")',
                'button:contains("Google Pay")',
                'button:contains("Pay with Apple Pay")',
                'button:contains("Pay with Google Pay")'
            ];
            
            let walletFound = false;
            for (const selector of walletSelectors) {
                try {
                    const element = await page.$(selector);
                    if (element) {
                        console.log(`Found wallet button with selector: ${selector}`);
                        walletFound = true;
                    }
                } catch (e) {
                    // Continue
                }
            }
            
            // Take final payment methods screenshot
            await page.screenshot({ path: 'screenshots/06_payment_methods.png', fullPage: true });
            console.log('✓ Payment methods screenshot saved');
            
            if (walletFound) {
                console.log('✓ Digital wallet options found!');
            } else {
                console.log('ℹ️ Digital wallet options may not be visible (device/browser dependent)');
            }
        }
        
        // Check page content for payment-related text
        const pageContent = await page.content();
        const hasStripe = pageContent.includes('stripe') || pageContent.includes('Stripe');
        const hasApplePay = pageContent.includes('Apple Pay') || pageContent.includes('apple-pay');
        const hasGooglePay = pageContent.includes('Google Pay') || pageContent.includes('google-pay');
        
        console.log('\n=== Payment Integration Analysis ===');
        console.log(`Stripe integration detected: ${hasStripe}`);
        console.log(`Apple Pay mentioned: ${hasApplePay}`);
        console.log(`Google Pay mentioned: ${hasGooglePay}`);
        
    } catch (error) {
        console.error('Error during booking flow test:', error);
        await page.screenshot({ path: 'screenshots/error.png', fullPage: true });
    } finally {
        await browser.close();
        console.log('\nBooking flow test completed!');
        console.log('Screenshots saved in ./screenshots/ directory');
    }
}

// Create screenshots directory
if (!fs.existsSync('screenshots')) {
    fs.mkdirSync('screenshots');
}

testBookingFlow().catch(console.error);